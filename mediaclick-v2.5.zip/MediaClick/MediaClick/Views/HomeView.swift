// HomeView.swift
// الشاشة الرئيسية (الرئيسية) — الترتيب من الأعلى إلى الأسفل:
//  1) شعار HDGrabber
//  2) الشعار النصي: حمّل من جميع المنصات بدقة عالية 4K
//  3) صف أيقونات المنصات الأصلية (للعرض فقط — ليست قابلة للضغط إطلاقًا)
//  4) كلمة «تحميل» وتحتها خانة الرابط (خانة واحدة فقط في التطبيق كله)
//  • لصق رابط يبدأ التحميل تلقائيًا فورًا (بلا ضغطة زر)؛ وزر تحميل
//    احتياطي للرابط المكتوب يدويًا.
//  • أثناء التحميل تُستبدل الخانة ببطاقة تقدم (المنصة المكتشفة + التقدم الحي).
//  • بعد اكتمال التحميل تعود الخانة العلوية من جديد للصق رابط آخر.
//  • النتائج تظهر أسفل الخانة كأيقونات: فيديو بمصغّرة حقيقية، صوت،
//    وأيقونة واحدة للصور عليها عدد الصور المحمّلة.

import SwiftUI
import UIKit
import Photos

struct HomeView: View {
    @StateObject private var manager = DownloadManager.shared
    @StateObject private var library = LibraryStore.shared
    @EnvironmentObject private var lang: LanguageManager

    @State private var linkText = ""
    @State private var autoStartTask: Task<Void, Never>?
    @State private var pastedURL: String?
    @State private var clipboardURL: URL?
    @State private var showInvalidAlert = false
    @State private var selectedResult: DownloadResult?
    @State private var selectedFile: LibraryFile?

    /// المنصة المكتشفة من النص الحالي (فوري، بلا شبكة).
    private var detectedPlatform: Platform? {
        guard let url = PlatformDetector.normalizeURL(linkText) else { return nil }
        return PlatformDetector.detect(from: url)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                // 1) الشعار
                logoSection
                // 2) الشعار النصي
                taglineSection
                // 3) أيقونات المنصات (عرض فقط)
                PlatformIconsRow()
                    .padding(.top, 2)
                // 4) خانة الرابط أو بطاقة التقدم أثناء التحميل
                if manager.activeJobs.isEmpty {
                    linkSection
                } else {
                    activeJobsSection
                }
                // النتائج كأيقونات
                if !manager.recentResults.isEmpty {
                    resultsSection
                }
                // تلميح الاستخدام (يظهر فقط قبل أول تحميل)
                if manager.recentResults.isEmpty && manager.activeJobs.isEmpty {
                    hintSection
                }
                Spacer(minLength: 24)
            }
            .padding(.horizontal, 20)
            .padding(.top, 8)
        }
        .background(Brand.background.ignoresSafeArea())
        .alert(lang.t("invalid_url_title"), isPresented: $showInvalidAlert) {
            Button(lang.t("ok"), role: .cancel) {}
        } message: {
            Text(lang.t("invalid_url_message"))
        }
        .sheet(item: $selectedResult) { result in
            ResultDetailSheet(result: result)
        }
        .sheet(item: $selectedFile) { file in
            MediaPlayerView(file: file)
        }
    }

    // MARK: - 1) الشعار

    private var logoSection: some View {
        VStack(spacing: 4) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(
                            LinearGradient(colors: [Brand.primary, Color(red: 0.6, green: 0.05, blue: 0.35)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .frame(width: 52, height: 52)
                    Image(systemName: "arrow.down.to.line")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                }
                Text("HDGrabber")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)
            }
        }
        .padding(.top, 10)
    }

    // MARK: - 2) الشعار النصي

    private var taglineSection: some View {
        Text(lang.t("tagline"))
            .font(.system(size: 17, weight: .semibold))
            .foregroundColor(Brand.textSecondary)
            .multilineTextAlignment(.center)
    }

    // MARK: - 4) خانة الرابط (الوحيدة) + زر تحميل
    // اللصق هو الطريقة الرئيسية لإدخال الرابط: زر لصق واضح داخل الخانة،
    // وقبول اللصق بالضغطة المطوّلة وبلوحة المفاتيح، وشريحة اقتراح عند
    // فتح الشاشة إن كانت الحافظة تحمل رابطًا.

    private var linkSection: some View {
        VStack(spacing: 12) {
            Text(lang.t("download_title"))
                .font(.system(size: 26, weight: .black))
                .foregroundColor(Brand.textPrimary)
                .frame(maxWidth: .infinity, alignment: .trailing)

            // الخانة + زر اللصق داخلها
            HStack(spacing: 8) {
                TextField(lang.t("link_placeholder"), text: $linkText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                    .textContentType(.URL)
                    .font(.system(size: 15))
                    .foregroundColor(Brand.textPrimary)
                    .padding(.vertical, 14)
                    .onChange(of: linkText) { _ in onLinkTextChanged() }

                // زر اللصق داخل الخانة — واضح وبضغطة واحدة
                Button(action: pasteFromClipboard) {
                    HStack(spacing: 4) {
                        Image(systemName: "doc.on.clipboard")
                            .font(.system(size: 15, weight: .semibold))
                        Text(lang.t("paste"))
                            .font(.system(size: 14, weight: .bold))
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Capsule().fill(Brand.accent))
                }
                .accessibilityLabel("لصق الرابط من الحافظة")
            }
            .padding(.horizontal, 12)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Brand.card)
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(detectedPlatform == nil
                                    ? Brand.cardBorder
                                    : Brand.accent.opacity(0.6), lineWidth: 1.5)))

            // شريحة اقتراح: الحافظة تحمل رابطًا عند فتح الشاشة
            if let clip = clipboardURL, linkText.isEmpty {
                Button(action: pasteFromClipboard) {
                    HStack(spacing: 6) {
                        Image(systemName: "link")
                            .font(.system(size: 13))
                        Text(lang.t("paste_chip"))
                            .font(.system(size: 13, weight: .semibold))
                        Text(clip.host ?? "")
                            .font(.system(size: 12))
                            .foregroundColor(Brand.textMuted)
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Capsule().fill(Brand.accent.opacity(0.25)))
                    .overlay(Capsule().stroke(Brand.accent.opacity(0.5), lineWidth: 1))
                }
            }

            // المنصة المكتشفة تظهر فورًا (بلا شبكة) بمجرد اكتمال الرابط
            if let platform = detectedPlatform {
                HStack {
                    Text(lang.t("detected_platform"))
                        .font(.system(size: 13))
                        .foregroundColor(Brand.textSecondary)
                    PlatformChip(platform: platform)
                    Spacer()
                    Text(lang.t("auto_start_note"))
                        .font(.system(size: 12))
                        .foregroundColor(Brand.textMuted)
                }
            }

            // زر تحميل — احتياطي للرابط المكتوب يدويًا (اللصق يبدأ تلقائيًا)
            Button(action: startFromField) {
                HStack {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 20))
                    Text(lang.t("download_title"))
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(
                    LinearGradient(colors: [Brand.primary, Color(red: 0.75, green: 0.08, blue: 0.35)],
                                   startPoint: .leading, endPoint: .trailing)
                )
                .clipShape(RoundedRectangle(cornerRadius: 16))
                .shadow(color: Brand.primary.opacity(0.35), radius: 12, x: 0, y: 6)
            }
        }
        .onAppear(perform: checkClipboard)
    }

    // MARK: - بطاقات التقدم أثناء التحميل

    private var activeJobsSection: some View {
        VStack(spacing: 12) {
            ForEach(manager.activeJobs) { job in
                ActiveJobCard(job: job, onCancel: {
                    manager.cancelJob(job)
                })
            }
        }
    }

    // MARK: - النتائج كأيقونات

    private var resultsSection: some View {
        VStack(spacing: 14) {
            SectionTitle(text: lang.t("results_title"))
            ForEach(manager.recentResults) { result in
                ResultRow(result: result,
                          onVideo: { if let f = result.videoFile { selectedFile = f } },
                          onAudio: { if let f = result.audioFile { selectedFile = f } },
                          onImages: { selectedResult = result })
            }
        }
    }

    // MARK: - تلميح

    private var hintSection: some View {
        VStack(spacing: 8) {
            Text(lang.t("how_it_works_title"))
                .font(.system(size: 15, weight: .bold))
                .foregroundColor(Brand.textPrimary)
            Text(lang.t("how_it_works_body"))
                .font(.system(size: 13))
                .foregroundColor(Brand.textSecondary)
                .multilineTextAlignment(.center)
                .lineSpacing(4)
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Brand.card)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Brand.cardBorder, lineWidth: 1)))
    }

    // MARK: - المنطق

    /// فحص الحافظة عند فتح الشاشة: إن حملت رابطًا يُعرض كشريحة اقتراح.
    private func checkClipboard() {
        guard let text = UIPasteboard.general.string,
              let url = PlatformDetector.normalizeURL(text),
              let parsed = URL(string: url) else {
            clipboardURL = nil
            return
        }
        clipboardURL = parsed
    }

    /// لصق الرابط من الحافظة إلى الخانة — يبدأ التحميل تلقائيًا عبر
    /// onLinkTextChanged (لا حاجة لضغطة زر إضافية).
    private func pasteFromClipboard() {
        guard let text = UIPasteboard.general.string,
              let url = PlatformDetector.normalizeURL(text) else { return }
        clipboardURL = nil
        linkText = url
    }

    /// يُستدعى عند كل تغيير في نص الخانة: لصق رابط يبدأ التحميل تلقائيًا.
    private func onLinkTextChanged() {
        autoStartTask?.cancel()
        guard let url = PlatformDetector.normalizeURL(linkText) else { return }
        // مهلة قصيرة (0.5ث) حتى يستقر النص ثم ابدأ فورًا — هذا ما يجعل
        // اللصق يبدأ التحميل تلقائيًا دون انتظار ضغطة زر.
        let captured = url
        autoStartTask = Task {
            try? await Task.sleep(nanoseconds: 500_000_000)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                // لا تبدأ مرتين لنفس الرابط الجاري
                let already = manager.activeJobs.contains {
                    DownloadManager.normalizedURL($0.sourceURL) ==
                        DownloadManager.normalizedURL(captured)
                }
                if already { return }
                if manager.startDownload(urlString: captured) != nil {
                    linkText = "" // تُفرَّغ الخانة؛ وتعود بعد اكتمال التحميل
                    pastedURL = captured
                } else {
                    // رابط نُزّل من قبل: عُرض من الذاكرة فورًا
                    linkText = ""
                }
            }
        }
    }

    /// زر تحميل (لروابط تُكتب يدويًا).
    private func startFromField() {
        guard let url = PlatformDetector.normalizeURL(linkText) else {
            showInvalidAlert = true
            return
        }
        autoStartTask?.cancel()
        if manager.startDownload(urlString: url) != nil {
            linkText = ""
        } else {
            linkText = ""
        }
    }

}

// MARK: - بطاقة مهمة نشطة (تقدم حي)

struct ActiveJobCard: View {
    @ObservedObject var job: ActiveJob
    var onCancel: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                PlatformChip(platform: job.platform)
                Text(job.statusText)
                    .font(.system(size: 13))
                    .foregroundColor(Brand.textSecondary)
                    .lineLimit(1)
                Spacer()
                Text("\(Int(job.progress * 100))٪")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
                    .monospacedDigit()
                Button(action: onCancel) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 20))
                        .foregroundColor(Brand.textMuted)
                }
                .accessibilityLabel("إلغاء التحميل")
            }
            DownloadProgressBar(progress: job.progress)
            if case .failed(let msg) = job.state {
                HStack {
                    Text(msg)
                        .font(.system(size: 13))
                        .foregroundColor(Brand.warning)
                    Spacer()
                    Button(LanguageManager.shared.t("retry")) {
                        DownloadManager.shared.retryJob(sourceURL: job.sourceURL)
                    }
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(Brand.accent)
                }
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Brand.card)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Brand.cardBorder, lineWidth: 1)))
    }
}

// MARK: - صف نتيجة واحدة (فيديو/صوت/صور كأيقونات)

struct ResultRow: View {
    var result: DownloadResult
    var onVideo: () -> Void
    var onAudio: () -> Void
    var onImages: () -> Void

    @EnvironmentObject private var lang: LanguageManager

    @State private var videoThumb: UIImage?
    @State private var saveMessage: String?

    var body: some View {
        VStack(spacing: 10) {
            HStack {
                PlatformChip(platform: result.platform)
                if let title = result.title, !title.isEmpty {
                    Text(title)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(Brand.textPrimary)
                        .lineLimit(1)
                }
                Spacer()
                if !result.durationText.isEmpty {
                    Text(result.durationText)
                        .font(.system(size: 12))
                        .foregroundColor(Brand.textMuted)
                        .monospacedDigit()
                }
            }
            // بطاقات النتائج في شبكة مرنة من 3 أعمدة — تتقلص البطاقات
            // تلقائيًا على الشاشات الضيقة بدل قصّها.
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                if let v = result.videoFile {
                    ResultIconCard(
                        title: lang.t("video"),
                        subtitle: v.sizeText,
                        thumbnail: videoThumb,
                        systemIcon: "play.rectangle.fill",
                        tint: Brand.primary,
                        action: onVideo,
                        onSave: { FileActions.save(file: v) { saveMessage = $0 } },
                        onShare: { FileActions.share(file: v) })
                }
                if let a = result.audioFile {
                    ResultIconCard(
                        title: lang.t("audio"),
                        subtitle: a.sizeText,
                        systemIcon: "waveform",
                        tint: Brand.accent,
                        action: onAudio,
                        onSave: { FileActions.save(file: a) { saveMessage = $0 } },
                        onShare: { FileActions.share(file: a) })
                }
                if let img = result.imageFiles.first {
                    ResultIconCard(
                        title: lang.t("images"),
                        subtitle: String(format: lang.t("images_count"), result.imageFiles.count),
                        badge: "\(result.imageFiles.count)",
                        systemIcon: "photo.on.rectangle",
                        tint: Brand.success,
                        action: onImages,
                        onSave: { FileActions.save(file: img) { saveMessage = $0 } },
                        onShare: { FileActions.share(file: img) })
                }
            }
            if result.notice == "notice_video_too_big" {
                Text("الفيديو تجاوز 48MB فأُرسل الصوت فقط.")
                    .font(.system(size: 12))
                    .foregroundColor(Brand.warning)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Brand.card)
                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Brand.cardBorder, lineWidth: 1)))
        .onAppear(perform: loadThumb)
        .alert("حفظ", isPresented: .constant(saveMessage != nil)) {
            Button("حسنًا", role: .cancel) { saveMessage = nil }
        } message: {
            Text(saveMessage ?? "")
        }
    }

    private func loadThumb() {
        guard let file = result.videoFile else { return }
        if let url = file.thumbnailURL,
           let img = UIImage(contentsOfFile: url.path) {
            videoThumb = img
            return
        }
        // توليد محلي من الفيديو نفسه
        DispatchQueue.global(qos: .userInitiated).async {
            if let gen = ThumbnailGenerator.videoThumbnail(for: file.fileURL),
               let img = UIImage(contentsOfFile: gen.path) {
                DispatchQueue.main.async { videoThumb = img }
            }
        }
    }
}

// MARK: - ورقة تفاصيل نتيجة (معرض الصور)

struct ResultDetailSheet: View {
    var result: DownloadResult
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    if !result.imageFiles.isEmpty {
                        SectionTitle(text: "الصور (\(result.imageFiles.count))")
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                            ForEach(result.imageFiles) { file in
                                if let img = UIImage(contentsOfFile: file.fileURL.path) {
                                    Image(uiImage: img)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(height: 110)
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                            }
                        }
                    }
                    if let v = result.videoFile {
                        HStack {
                            Text("الفيديو: \(v.name)")
                            Spacer()
                            Text(v.sizeText)
                        }
                        .font(.system(size: 13))
                        .foregroundColor(Brand.textSecondary)
                    }
                    if let a = result.audioFile {
                        HStack {
                            Text("الصوت: \(a.name)")
                            Spacer()
                            Text(a.sizeText)
                        }
                        .font(.system(size: 13))
                        .foregroundColor(Brand.textSecondary)
                    }
                }
                .padding()
            }
            .background(Brand.background.ignoresSafeArea())
            .navigationTitle(result.title ?? result.platform.displayName)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
            }
        }
    }
}

// MARK: - ورقة مشاركة النظام (عرض UIKit مباشر)

/// عرض ورقة المشاركة من UIKit مباشرة من أعلى شاشة ظاهرة —
/// تقديم UIActivityViewController عبر SwiftUI ‎.sheet كان يظهر شاشة
/// سوداء معلّقة عند فتحه من داخل المشغّل أو من داخل ورقة أخرى.
enum SharePresenter {
    static func present(items: [Any]) {
        guard let top = topViewController() else { return }
        let vc = UIActivityViewController(activityItems: items, applicationActivities: nil)
        if let pop = vc.popoverPresentationController {
            pop.sourceView = top.view
            pop.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY,
                                    width: 0, height: 0)
            pop.permittedArrowDirections = []
        }
        top.present(vc, animated: true)
    }

    /// حفظ ملف (صوت مثلاً) في تطبيق الملفات — الصور لا تقبل الصوت.
    /// يُعرض المنتقي بعد مهلة قصيرة حتى تُغلق أي قائمة سياقية
    /// مفتوحة (عرضه أثناءها يفشل بصمت)، ويرجع false إن لم يوجد
    /// عارض أصلًا (عندها يستخدم المتصل بديل ورقة المشاركة).
    @discardableResult
    static func exportToFiles(fileURL: URL) -> Bool {
        guard let top = topViewController() else { return false }
        let picker = UIDocumentPickerViewController(forExporting: [fileURL])
        picker.shouldShowFileExtensions = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            top.present(picker, animated: true)
        }
        return true
    }

    static func topViewController(base: UIViewController? = nil) -> UIViewController? {
        let baseVC: UIViewController?
        if let base = base {
            baseVC = base
        } else {
            baseVC = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .flatMap { $0.windows }
                .first { $0.isKeyWindow }?.rootViewController
        }
        if let nav = baseVC as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        if let tab = baseVC as? UITabBarController {
            return topViewController(base: tab.selectedViewController)
        }
        if let presented = baseVC?.presentedViewController {
            return topViewController(base: presented)
        }
        return baseVC
    }
}

// MARK: - إجراءات ملف مشتركة (حفظ/مشاركة)

/// حفظ ومشاركة ملف من أي مكان في التطبيق بنفس السلوك:
/// فيديو/صورة إلى الصور، وصوت إلى تطبيق الملفات (الصور لا تقبل الصوت).
enum FileActions {
    /// يحفظ الملف؛ ويعيد رسالة تأكيد عبر completion (nil للصوت —
    /// منتقي الملفات نفسه هو الواجهة).
    ///  • فيديو/صورة: إلى الصور بعد فحص الإذن — وإن كان الإذن
    ///    مرفوضًا يُرشد المستخدم للإعدادات، وإن رفضت الصور
    ///    الصيغة (مثل AV1) بديل فوري: الحفظ في تطبيق الملفات.
    ///  • صوت: الصور لا تقبل الصوت — منتقي الملفات مباشرة،
    ///    وبديل ورقة المشاركة إن تعذّر عرضه.
    static func save(file: LibraryFile, completion: @escaping (String?) -> Void) {
        guard FileManager.default.fileExists(atPath: file.fileURL.path) else {
            completion("الملف غير موجود على الجهاز — أعد تحميله.")
            return
        }
        switch file.kind {
        case .video, .image, .thumbnail:
            saveToPhotos(file: file, completion: completion)
        case .audio:
            if SharePresenter.exportToFiles(fileURL: file.fileURL) {
                completion(nil)
            } else {
                SharePresenter.present(items: [file.fileURL])
                completion("اختر «حفظ في الملفات» من ورقة المشاركة.")
            }
        }
    }

    /// حفظ في الصور مع فحص الإذن أولًا (بلا فحص، رفضٌ سابق
    /// للإذن يجعل كل حفظ يفشل بصمت برسالة «تعذّر الحفظ»).
    private static func saveToPhotos(file: LibraryFile, completion: @escaping (String?) -> Void) {
        switch PHPhotoLibrary.authorizationStatus(for: .addOnly) {
        case .authorized, .limited:
            performPhotosSave(file: file, completion: completion)
        case .notDetermined:
            PHPhotoLibrary.requestAuthorization(for: .addOnly) { newStatus in
                DispatchQueue.main.async {
                    if newStatus == .authorized || newStatus == .limited {
                        performPhotosSave(file: file, completion: completion)
                    } else {
                        completion("لم يُسمح بالوصول إلى الصور — فعّله من إعدادات الهاتف (الخصوصية والأمان ← الصور ← HDGrabber) ثم أعد المحاولة.")
                    }
                }
            }
        case .denied, .restricted:
            completion("الوصول إلى الصور مرفوض — فعّله من إعدادات الهاتف (الخصوصية والأمان ← الصور ← HDGrabber) ثم أعد المحاولة.")
        @unknown default:
            performPhotosSave(file: file, completion: completion)
        }
    }

    /// محاولة الحفظ في الصور نفسها؛ وعند الفشل (صيغة لا تدعمها
    /// الصور مثل AV1) بديل فوري في تطبيق الملفات.
    private static func performPhotosSave(file: LibraryFile, completion: @escaping (String?) -> Void) {
        PHPhotoLibrary.shared().performChanges {
            if file.kind == .video {
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: file.fileURL)
            } else {
                PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: file.fileURL)
            }
        } completionHandler: { ok, _ in
            DispatchQueue.main.async {
                if ok {
                    completion("تم الحفظ في الصور.")
                } else {
                    SharePresenter.present(items: [file.fileURL])
                    completion("تعذّر الحفظ في الصور (الصيغة غير مدعومة) — اختر «حفظ في الملفات» من ورقة المشاركة.")
                }
            }
        }
    }

    static func share(file: LibraryFile) {
        SharePresenter.present(items: [file.fileURL])
    }
}
