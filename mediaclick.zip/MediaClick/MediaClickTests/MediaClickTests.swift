// MediaClickTests.swift
// اختبارات وحدة التطبيق — حتمية (نفس المدخلات تعطي نفس النتيجة دائمًا):
//  كاشف المنصة، التحقق من الروابط، قواعد الحدود (الحجم/المدة)،
//  آلة حالات التحميل، وتغطية الترجمة.
// تُشغَّل في Xcode: Product → Test (⌘U).

import XCTest
@testable import MediaClick

// MARK: - كاشف المنصة

final class PlatformDetectorTests: XCTestCase {
    func testYouTubeHosts() {
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"), .youtube)
        XCTAssertEqual(PlatformDetector.detect(from: "https://youtu.be/dQw4w9WgXcQ"), .youtube)
        XCTAssertEqual(PlatformDetector.detect(from: "https://m.youtube.com/watch?v=abc"), .youtube)
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.youtube-nocookie.com/embed/abc"), .youtube)
    }

    func testTikTokHostsIncludingShortLinks() {
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.tiktok.com/@user/video/123"), .tiktok)
        XCTAssertEqual(PlatformDetector.detect(from: "https://vm.tiktok.com/abc123/"), .tiktok)
        XCTAssertEqual(PlatformDetector.detect(from: "https://vt.tiktok.com/abc123/"), .tiktok)
    }

    func testInstagramFacebookX() {
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.instagram.com/reel/abc/"), .instagram)
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.instagram.com/p/abc/"), .instagram)
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.facebook.com/watch/?v=123"), .facebook)
        XCTAssertEqual(PlatformDetector.detect(from: "https://fb.watch/abc/"), .facebook)
        XCTAssertEqual(PlatformDetector.detect(from: "https://x.com/user/status/123"), .x)
        XCTAssertEqual(PlatformDetector.detect(from: "https://twitter.com/user/status/123"), .x)
    }

    func testOtherPlatforms() {
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.pinterest.com/pin/123/"), .pinterest)
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.twitch.tv/somechannel"), .twitch)
        XCTAssertEqual(PlatformDetector.detect(from: "https://www.linkedin.com/posts/abc"), .linkedin)
        XCTAssertEqual(PlatformDetector.detect(from: "https://example.tumblr.com/post/123"), .tumblr)
        XCTAssertEqual(PlatformDetector.detect(from: "https://soundcloud.com/artist/track"), .soundcloud)
    }

    func testUnknownPlatform() {
        XCTAssertEqual(PlatformDetector.detect(from: "https://example.com/video.mp4"), .unknown)
        XCTAssertEqual(PlatformDetector.detect(from: "not a url"), .unknown)
        XCTAssertEqual(PlatformDetector.detect(from: ""), .unknown)
    }

    func testDetectionIsCaseInsensitive() {
        XCTAssertEqual(PlatformDetector.detect(from: "HTTPS://WWW.YOUTUBE.COM/watch?v=abc"), .youtube)
        XCTAssertEqual(PlatformDetector.detect(from: "https://WWW.TIKTOK.COM/@u/video/1"), .tiktok)
    }

    func testDetectionIsDeterministic() {
        // نفس الرابط يعطي نفس النتيجة في كل مرة (بلا عشوائية)
        let url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        let first = PlatformDetector.detect(from: url)
        for _ in 0..<100 {
            XCTAssertEqual(PlatformDetector.detect(from: url), first)
        }
    }
}

// MARK: - التحقق من الروابط

final class URLValidationTests: XCTestCase {
    func testValidURLs() {
        XCTAssertTrue(PlatformDetector.isValidURL("https://www.youtube.com/watch?v=abc"))
        XCTAssertTrue(PlatformDetector.isValidURL("http://example.com/video.mp4"))
        XCTAssertTrue(PlatformDetector.isValidURL("  https://tiktok.com/@u/video/1  "))
    }

    func testInvalidURLs() {
        XCTAssertFalse(PlatformDetector.isValidURL(""))
        XCTAssertFalse(PlatformDetector.isValidURL("not a url"))
        XCTAssertFalse(PlatformDetector.isValidURL("ftp://example.com/file"))
        XCTAssertFalse(PlatformDetector.isValidURL("youtube.com/watch?v=abc")) // بلا مخطط
        XCTAssertFalse(PlatformDetector.isValidURL("https://"))
    }

    func testExtractURLFromMixedText() {
        let text = "شاهد هذا: https://youtu.be/dQw4w9WgXcQ رائع!"
        XCTAssertEqual(PlatformDetector.extractURL(from: text),
                       "https://youtu.be/dQw4w9WgXcQ")
        XCTAssertNil(PlatformDetector.extractURL(from: "لا يوجد رابط هنا"))
    }
}

// MARK: - قواعد الحدود (الحجم/المدة)

final class DownloadRulesTests: XCTestCase {
    private let mb = 1024 * 1024

    func testDurationAllowed() {
        XCTAssertTrue(DownloadRules.isDurationAllowed(nil))
        XCTAssertTrue(DownloadRules.isDurationAllowed(0))
        XCTAssertTrue(DownloadRules.isDurationAllowed(3600))
        XCTAssertTrue(DownloadRules.isDurationAllowed(3599))
        XCTAssertFalse(DownloadRules.isDurationAllowed(3601))
        XCTAssertFalse(DownloadRules.isDurationAllowed(7200))
    }

    func testSizeAllowed() {
        XCTAssertTrue(DownloadRules.isSizeAllowed(48 * mb))
        XCTAssertTrue(DownloadRules.isSizeAllowed(1024))
        XCTAssertFalse(DownloadRules.isSizeAllowed(48 * mb + 1))
        XCTAssertFalse(DownloadRules.isSizeAllowed(nil))
    }

    func testDecideBothOK() {
        let d = DownloadRules.decide(videoSize: 20 * mb, audioSize: 5 * mb)
        XCTAssertEqual(d, .both)
    }

    func testDecideVideoOverCapAudioOK() {
        // فيديو فوق السقف + صوت سليم ← صوت فقط + تنبيه
        let d = DownloadRules.decide(videoSize: 60 * mb, audioSize: 5 * mb)
        XCTAssertEqual(d, .audioOnlyWithNotice)
        XCTAssertEqual(d.notice, "notice_video_too_big")
        XCTAssertFalse(d.includeVideo)
        XCTAssertTrue(d.includeAudio)
    }

    func testDecideVideoMissingAudioOK() {
        // بلا فيديو إطلاقًا (videoSize=nil) + صوت سليم ← صوت فقط + تنبيه
        // (يطابق مسار البوت عند غياب مزيج فيديو يناسب)
        let d = DownloadRules.decide(videoSize: nil, audioSize: 5 * mb)
        XCTAssertEqual(d, .audioOnlyWithNotice)
    }

    func testDecideVideoOKAudioOver() {
        // فيديو سليم + صوت فوق السقف ← فيديو وحده بصمت
        let d = DownloadRules.decide(videoSize: 20 * mb, audioSize: 60 * mb)
        XCTAssertEqual(d, .videoOnly)
        XCTAssertNil(d.notice)
        XCTAssertNil(d.error)
    }

    func testDecideBothOver() {
        let d = DownloadRules.decide(videoSize: 60 * mb, audioSize: 60 * mb)
        XCTAssertEqual(d, .fileTooBig)
        XCTAssertEqual(d.error, "err_file_too_big")
    }

    func testDecideBothFailed() {
        let d = DownloadRules.decide(videoSize: nil, audioSize: nil)
        XCTAssertEqual(d, .downloadFailed)
        XCTAssertEqual(d.error, "err_download")
    }

    func testDecideIsDeterministic() {
        for _ in 0..<50 {
            XCTAssertEqual(
                DownloadRules.decide(videoSize: 60 * mb, audioSize: 5 * mb),
                .audioOnlyWithNotice)
        }
    }

    func testPhotoURLDetection() {
        XCTAssertTrue(DownloadRules.isPhotoURL("https://www.tiktok.com/@u/photo/123"))
        XCTAssertTrue(DownloadRules.isPhotoURL("https://www.instagram.com/p/abc/"))
        XCTAssertTrue(DownloadRules.isPhotoURL("https://www.pinterest.com/pin/123/"))
        XCTAssertTrue(DownloadRules.isPhotoURL("https://example.com/photo.jpg"))
        XCTAssertFalse(DownloadRules.isPhotoURL("https://www.tiktok.com/@u/video/123"))
        XCTAssertFalse(DownloadRules.isPhotoURL("https://www.instagram.com/reel/abc/"))
        XCTAssertFalse(DownloadRules.isPhotoURL("https://www.youtube.com/watch?v=abc"))
    }
}

// MARK: - آلة حالات التحميل

final class DownloadStateMachineTests: XCTestCase {
    func testJobStatusArabicNames() {
        XCTAssertEqual(JobStatus.queued.arabicName, "في الانتظار")
        XCTAssertEqual(JobStatus.probing.arabicName, "جارٍ فحص الرابط…")
        XCTAssertEqual(JobStatus.downloading.arabicName, "جارٍ التحميل…")
        XCTAssertEqual(JobStatus.done.arabicName, "اكتمل")
        XCTAssertEqual(JobStatus.error.arabicName, "تعذّر")
    }

    func testJobStatusIsActive() {
        XCTAssertTrue(JobStatus.queued.isActive)
        XCTAssertTrue(JobStatus.probing.isActive)
        XCTAssertTrue(JobStatus.downloading.isActive)
        XCTAssertFalse(JobStatus.done.isActive)
        XCTAssertFalse(JobStatus.error.isActive)
    }

    func testActiveJobInitialState() {
        let job = ActiveJob(sourceURL: "https://www.youtube.com/watch?v=abc",
                            platform: .youtube)
        XCTAssertTrue(job.isActive)
        XCTAssertEqual(job.progress, 0)
        XCTAssertEqual(job.platform, .youtube)
        XCTAssertNil(job.serverJobId)
        XCTAssertNil(job.result)
    }

    func testEveryErrorKeyHasMessage() {
        // كل مفتاح خطأ يعرفه الخادم له رسالة واضحة (لا رسالة فارغة أبدًا)
        let keys = ["err_login_required", "err_instagram_login",
                    "err_facebook_login", "err_playlist", "err_live",
                    "err_too_long", "err_no_media", "err_no_photos",
                    "err_file_too_big", "err_disk_low", "err_probe",
                    "err_timeout", "err_download", "err_invalid_url", nil]
        for key in keys {
            let msg = ServerErrorMessage.arabic(for: key)
            XCTAssertFalse(msg.isEmpty, "empty message for \(key ?? "nil")")
        }
    }
}

// MARK: - تغطية الترجمة

final class LocalizationTests: XCTestCase {
    func testAllLanguagesHaveCoreKeys() {
        let coreKeys = ["menu_home", "menu_files", "menu_support",
                        "download_title", "link_placeholder", "paste",
                        "video", "audio", "images", "cancel", "retry",
                        "ok", "close", "share", "delete"]
        for lang in LanguageManager.supportedLanguages {
            for key in coreKeys {
                let text = L10n.text(key, lang: lang)
                XCTAssertFalse(text.isEmpty, "\(lang).\(key) is empty")
                XCTAssertNotEqual(text, key, "\(lang).\(key) fell back to key")
            }
        }
    }

    func testRTLlanguages() {
        XCTAssertTrue(L10n.rtlLanguages.contains("ar"))
        XCTAssertTrue(L10n.rtlLanguages.contains("fa"))
        XCTAssertTrue(L10n.rtlLanguages.contains("ur"))
        XCTAssertFalse(L10n.rtlLanguages.contains("en"))
    }

    func testFallbackNeverEmpty() {
        // مفتاح غير موجود يرجع المفتاح نفسه (لا فراغ ولا عطل)
        XCTAssertEqual(L10n.text("no_such_key_xyz", lang: "ar"), "no_such_key_xyz")
    }
}
