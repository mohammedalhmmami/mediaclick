// Platform.swift
// منصات التحميل المدعومة + كاشف المنصة من الرابط.
// يطابق تغطية المحرك (engine/) — 10 منصات تعمل بلا دخول.

import Foundation

/// منصة من المنصات المدعومة.
enum Platform: String, CaseIterable, Identifiable {
    case youtube
    case tiktok
    case instagram
    case facebook
    case x
    case pinterest
    case twitch
    case linkedin
    case tumblr
    case soundcloud
    case unknown

    var id: String { rawValue }

    /// الاسم العربي للعرض.
    var displayName: String {
        switch self {
        case .youtube: return "يوتيوب"
        case .tiktok: return "تيك توك"
        case .instagram: return "إنستغرام"
        case .facebook: return "فيسبوك"
        case .x: return "إكس"
        case .pinterest: return "بينترست"
        case .twitch: return "تويتش"
        case .linkedin: return "لينكدإن"
        case .tumblr: return "تمبلر"
        case .soundcloud: return "ساوند كلاود"
        case .unknown: return "منصة أخرى"
        }
    }

    /// اسم أيقونة العلامة في Asset Catalog (brand-<name>).
    /// الأيقونات للعرض فقط — ليست قابلة للضغط إطلاقًا.
    var iconName: String {
        switch self {
        case .unknown: return "globe"
        default: return "brand-\(rawValue)"
        }
    }

    /// هل هذه الأيقونة أيقونة علامة (صورة) أم رمز نظام؟
    var isBrandImage: Bool { self != .unknown }
}

/// كاشف المنصة من الرابط — يطابق مضيفات/أنماط المحرك.
/// يعرف المنصة من الـ URL نفسه قبل أي اتصال بالشبكة.
enum PlatformDetector {
    /// يكشف المنصة من رابط نصي. يرجع .unknown إن لم يطابق أي منصة معروفة.
    static func detect(from urlString: String) -> Platform {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let host = url.host?.lowercased() else { return .unknown }
        let h = host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
        let path = url.path.lowercased()

        // روابط مختصرة معروفة تُحلّ إلى منصتها الأصلية
        if h == "youtu.be" || h.hasSuffix("youtube.com") || h.hasSuffix("youtube-nocookie.com") {
            return .youtube
        }
        if h == "vm.tiktok.com" || h == "vt.tiktok.com" || h.hasSuffix("tiktok.com") {
            return .tiktok
        }
        if h.hasSuffix("instagram.com") || h == "instagr.am" {
            return .instagram
        }
        if h.hasSuffix("facebook.com") || h == "fb.watch" || h.hasSuffix("fb.com") {
            return .facebook
        }
        if h == "x.com" || h.hasSuffix("twitter.com") || h == "t.co" {
            return .x
        }
        if h.hasSuffix("pinterest.com") || h.hasSuffix("pin.it") {
            return .pinterest
        }
        if h.hasSuffix("twitch.tv") {
            return .twitch
        }
        if h.hasSuffix("linkedin.com") || h == "lnkd.in" {
            return .linkedin
        }
        if h.hasSuffix("tumblr.com") {
            return .tumblr
        }
        if h.hasSuffix("soundcloud.com") || h == "snd.sc" {
            return .soundcloud
        }
        // منصات أخرى يتعرف عليها yt-dlp لكنها بلا أيقونة علامة هنا
        _ = path
        return .unknown
    }

    /// هل النص رابط http/https صالح (يُستخدم قبل بدء التحميل)؟
    /// يشترط مخططًا ومضيفًا فيه نقطة (حتى لا يُقبل نص عادي).
    static func isValidURL(_ text: String) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let scheme = url.scheme?.lowercased(),
              (scheme == "http" || scheme == "https"),
              let host = url.host, host.contains(".") else { return false }
        return true
    }

    /// يستخرج أول رابط http/https من نص (لصق قد يحمل نصًا إضافيًا)،
    /// مع تنظيف علامات الترقيم الزائدة في نهايته (نقطة/قوس من رسالة).
    static func extractURL(from text: String) -> String? {
        let pattern = #"https?://[^\s<>"]+"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else {
            return nil
        }
        let range = NSRange(text.startIndex..., in: text)
        guard let match = regex.firstMatch(in: text, options: [], range: range),
              let urlRange = Range(match.range, in: text) else { return nil }
        let found = stripTrailingPunctuation(String(text[urlRange]))
        return found.isEmpty ? nil : found
    }

    /// يطبّع أي صيغة رابط إلى رابط http(s) صالح أو nil.
    /// يقبل: روابط بمخطط أو بلا مخطط (youtube.com/...)، وروابط
    /// مختصرة (youtu.be)، وروابط داخل نص إضافي، وروابط بعلامات
    /// ترقيم زائدة في النهاية. هذا ما يمنع رفض رابط صحيح.
    static func normalizeURL(_ text: String) -> String? {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let candidate: String
        if let found = extractURL(from: trimmed) {
            candidate = found
        } else if let bare = extractBareDomainURL(from: trimmed) {
            candidate = "https://" + bare
        } else {
            return nil
        }
        let cleaned = stripTrailingPunctuation(candidate)
            .replacingOccurrences(of: " ", with: "")
        guard isValidURL(cleaned) else { return nil }
        return cleaned
    }

    /// يستخرج أول رابط بلا مخطط (نطاق + مسار اختياري) من نص.
    /// يُقبل النطاق إن كان منصة معروفة أو حمل مسارًا (رابط حقيقي
    /// لا كلمة عادية فيها نقطة مثل رقم إصدار).
    private static func extractBareDomainURL(from text: String) -> String? {
        let pattern = #"(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:/[^\s<>"]*)?"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else {
            return nil
        }
        let range = NSRange(text.startIndex..., in: text)
        let known = ["youtube.com", "youtu.be", "youtube-nocookie.com",
                     "tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
                     "instagram.com", "instagr.am", "facebook.com", "fb.watch", "fb.com",
                     "x.com", "twitter.com", "t.co", "pinterest.com", "pin.it",
                     "twitch.tv", "linkedin.com", "lnkd.in", "tumblr.com",
                     "soundcloud.com", "snd.sc"]
        for m in regex.matches(in: text, options: [], range: range) {
            guard let r = Range(m.range, in: text) else { continue }
            let candidate = stripTrailingPunctuation(String(text[r]))
            guard !candidate.isEmpty else { continue }
            let host = candidate.split(separator: "/").first.map(String.init) ?? candidate
            let lower = host.lowercased()
            let isKnown = known.contains { lower == $0 || lower.hasSuffix("." + $0) }
            if isKnown || candidate.contains("/") { return candidate }
        }
        return nil
    }

    /// يزيل علامات الترقيم الزائدة من نهاية رابط (نقطة/فاصلة/قوس
    /// من نص رسالة) — معرّفات الوسائط لا تنتهي بها أبدًا.
    private static func stripTrailingPunctuation(_ s: String) -> String {
        var out = s
        while let last = out.last, ".,;:!?)}]\"'".contains(last) {
            out.removeLast()
        }
        return out
    }
}
