// Platform.swift
// منصات التحميل المدعومة + كاشف المنصة من الرابط.
// يطابق تغطية المحرك (engine/) — 10 منصات تعمل بلا دخول.

import Foundation

/// منصة من المنصات المدعومة.
enum Platform: String, CaseIterable, Identifiable {
    case youtube
    case tiktok
    case instagram
    case facebook
    case x
    case pinterest
    case twitch
    case linkedin
    case tumblr
    case soundcloud
    case unknown

    var id: String { rawValue }

    /// الاسم العربي للعرض.
    var displayName: String {
        switch self {
        case .youtube: return "يوتيوب"
        case .tiktok: return "تيك توك"
        case .instagram: return "إنستغرام"
        case .facebook: return "فيسبوك"
        case .x: return "إكس"
        case .pinterest: return "بينترست"
        case .twitch: return "تويتش"
        case .linkedin: return "لينكدإن"
        case .tumblr: return "تمبلر"
        case .soundcloud: return "ساوند كلاود"
        case .unknown: return "منصة أخرى"
        }
    }

    /// اسم أيقونة العلامة في Asset Catalog (brand-<name>).
    /// الأيقونات للعرض فقط — ليست قابلة للضغط إطلاقًا.
    var iconName: String {
        switch self {
        case .unknown: return "globe"
        default: return "brand-\(rawValue)"
        }
    }

    /// هل هذه الأيقونة أيقونة علامة (صورة) أم رمز نظام؟
    var isBrandImage: Bool { self != .unknown }
}

/// كاشف المنصة من الرابط — يطابق مضيفات/أنماط المحرك.
/// يعرف المنصة من الـ URL نفسه قبل أي اتصال بالشبكة.
enum PlatformDetector {
    /// يكشف المنصة من رابط نصي. يرجع .unknown إن لم يطابق أي منصة معروفة.
    static func detect(from urlString: String) -> Platform {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let host = url.host?.lowercased() else { return .unknown }
        let h = host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
        let path = url.path.lowercased()

        // روابط مختصرة معروفة تُحلّ إلى منصتها الأصلية
        if h == "youtu.be" || h.hasSuffix("youtube.com") || h.hasSuffix("youtube-nocookie.com") {
            return .youtube
        }
        if h == "vm.tiktok.com" || h == "vt.tiktok.com" || h.hasSuffix("tiktok.com") {
            return .tiktok
        }
        if h.hasSuffix("instagram.com") || h == "instagr.am" {
            return .instagram
        }
        if h.hasSuffix("facebook.com") || h == "fb.watch" || h.hasSuffix("fb.com") {
            return .facebook
        }
        if h == "x.com" || h.hasSuffix("twitter.com") || h == "t.co" {
            return .x
        }
        if h.hasSuffix("pinterest.com") || h.hasSuffix("pin.it") {
            return .pinterest
        }
        if h.hasSuffix("twitch.tv") {
            return .twitch
        }
        if h.hasSuffix("linkedin.com") || h == "lnkd.in" {
            return .linkedin
        }
        if h.hasSuffix("tumblr.com") {
            return .tumblr
        }
        if h.hasSuffix("soundcloud.com") || h == "snd.sc" {
            return .soundcloud
        }
        // منصات أخرى يتعرف عليها yt-dlp لكنها بلا أيقونة علامة هنا
        _ = path
        return .unknown
    }

    /// هل النص رابط http/https صالح (يُستخدم قبل بدء التحميل)؟
    static func isValidURL(_ text: String) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed),
              let scheme = url.scheme?.lowercased(),
              (scheme == "http" || scheme == "https"),
              url.host != nil else { return false }
        return true
    }

    /// يستخرج أول رابط http/https من نص (لصق قد يحمل نصًا إضافيًا).
    static func extractURL(from text: String) -> String? {
        let pattern = #"https?://[^\s<>"]+"#
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else {
            return nil
        }
        let range = NSRange(text.startIndex..., in: text)
        guard let match = regex.firstMatch(in: text, options: [], range: range),
              let urlRange = Range(match.range, in: text) else { return nil }
        return String(text[urlRange])
    }
}
