// DownloadJob.swift
// نماذج مهمة التحميل: ما يرجعه الخادم + نتيجة التحميل بعد حفظ الملفات على الجهاز.

import Foundation

/// نوع الوسائط في ملف واحد.
enum MediaKind: String, Codable, CaseIterable {
    case video
    case audio
    case image
    case thumbnail

    var arabicName: String {
        switch self {
        case .video: return "فيديو"
        case .audio: return "صوت"
        case .image: return "صورة"
        case .thumbnail: return "مصغّرة"
        }
    }
}

/// ملف واحد ضمن نتيجة مهمة من الخادم.
struct ServerFile: Codable, Identifiable {
    var kind: MediaKind
    var name: String
    var size: Int
    var url: String

    var id: String { name }

    var sizeText: String {
        ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }
}

/// حالة المهمة على الخادم.
enum JobStatus: String, Codable {
    case queued
    case probing
    case downloading
    case done
    case error

    var arabicName: String {
        switch self {
        case .queued: return "في الانتظار"
        case .probing: return "جارٍ فحص الرابط…"
        case .downloading: return "جارٍ التحميل…"
        case .done: return "اكتمل"
        case .error: return "تعذّر"
        }
    }

    var isActive: Bool {
        self == .queued || self == .probing || self == .downloading
    }
}

/// حالة مهمة كاملة كما يرجعها الخادم (GET /api/job/{id}).
struct ServerJob: Codable {
    var jobId: String
    var status: JobStatus
    var platform: String?
    var title: String?
    var duration: Double?
    /// تقدم حي 0...100 (من الخادم — يُقرأ من أول ثانية).
    var progress: Int
    var notice: String?
    var error: String?
    var files: [ServerFile]

    enum CodingKeys: String, CodingKey {
        case jobId = "job_id"
        case status, platform, title, duration, progress, notice, error, files
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        jobId = try c.decode(String.self, forKey: .jobId)
        status = try c.decode(JobStatus.self, forKey: .status)
        platform = try c.decodeIfPresent(String.self, forKey: .platform)
        title = try c.decodeIfPresent(String.self, forKey: .title)
        duration = try c.decodeIfPresent(Double.self, forKey: .duration)
        progress = try c.decodeIfPresent(Int.self, forKey: .progress) ?? 0
        notice = try c.decodeIfPresent(String.self, forKey: .notice)
        error = try c.decodeIfPresent(String.self, forKey: .error)
        files = try c.decodeIfPresent([ServerFile].self, forKey: .files) ?? []
    }
}

/// نتيجة مهمة بعد حفظ ملفاتها على الجهاز — ما يعرضه التطبيق كأيقونات.
struct DownloadResult: Identifiable {
    var id: String
    var sourceURL: String
    var platform: Platform
    var title: String?
    var duration: Double?
    var notice: String?
    var videoFile: LibraryFile?
    var audioFile: LibraryFile?
    var imageFiles: [LibraryFile]
    var createdAt: Date

    /// مدة المقطع كنص (مثال: 02:34) أو فارغ.
    var durationText: String {
        guard let d = duration, d > 0 else { return "" }
        let m = Int(d) / 60
        let s = Int(d) % 60
        return String(format: "%02d:%02d", m, s)
    }
}

/// رسالة خطأ مترجمة لمفاتيح أخطاء الخادم (نفس مفاتيح البوت err_*).
/// يستخدم ترجمات البوت (20 لغة) من L10n — كل خطأ له رسالة واضحة
/// بلغة المستخدم، ولا يظهر خطأ خام أو صامت أبدًا.
enum ServerErrorMessage {
    static func arabic(for key: String?) -> String {
        guard let key = key, !key.isEmpty else {
            return LanguageManager.shared.t("err_download")
        }
        // مفاتيح err_* موجودة في جدول L10n (من ترجمات البوت)؛
        // والمفاتيح غير المعروفة تسقط إلى رسالة التحميل العامة.
        let known = ["err_login_required", "err_instagram_login",
                     "err_facebook_login", "err_playlist", "err_live",
                     "err_too_long", "err_no_media", "err_no_photos",
                     "err_file_too_big", "err_disk_low", "err_probe",
                     "err_timeout", "err_download", "notice_video_too_big"]
        if known.contains(key) {
            return LanguageManager.shared.t(key)
        }
        if key == "err_invalid_url" {
            return LanguageManager.shared.t("invalid_url_message")
        }
        return LanguageManager.shared.t("err_download")
    }
}
