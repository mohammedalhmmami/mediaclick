// LibraryFile.swift
// ملف محفوظ في مكتبة الجهاز (ملفاتي) — بياناته محفوظة كـ JSON، والملف نفسه
// في مجلد Documents/MediaClick/.

import Foundation

/// ملف واحد في المكتبة.
struct LibraryFile: Identifiable, Codable, Equatable {
    var id: String
    var name: String
    var kind: MediaKind
    var size: Int
    var platform: String
    var sourceURL: String
    var title: String?
    var duration: Double?
    /// المسار النسبي داخل Documents/MediaClick/ (مثال: "video-abc123.mp4").
    var relativePath: String
    /// مسار المصغّرة النسبي (للفيديو فقط) أو nil.
    var thumbnailPath: String?
    var createdAt: Date

    /// المسار الكامل للملف على الجهاز.
    var fileURL: URL {
        LibraryStore.libraryDirectory.appendingPathComponent(relativePath)
    }

    /// المسار الكامل للمصغّرة أو nil.
    var thumbnailURL: URL? {
        guard let t = thumbnailPath else { return nil }
        return LibraryStore.libraryDirectory.appendingPathComponent(t)
    }

    var sizeText: String {
        ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }

    var dateText: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ar")
        f.dateStyle = .medium
        f.timeStyle = .short
        return f.string(from: createdAt)
    }

    var platformEnum: Platform {
        Platform(rawValue: platform) ?? .unknown
    }

    var durationText: String {
        guard let d = duration, d > 0 else { return "" }
        let m = Int(d) / 60
        let s = Int(d) % 60
        return String(format: "%02d:%02d", m, s)
    }
}
