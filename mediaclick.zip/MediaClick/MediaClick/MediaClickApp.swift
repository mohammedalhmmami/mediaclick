// MediaClickApp.swift
// نقطة دخول التطبيق — واجهة عربية RTL، سمة داكنة دائمًا،
 // وربط جلسة التحميل الخلفية (URLSession) عبر AppDelegate.

import SwiftUI
import UIKit

/// مندوب التطبيق — يستقبل أحداث جلسة URLSession الخلفية.
final class AppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        handleEventsForBackgroundURLSession identifier: String,
        completionHandler: @escaping () -> Void
    ) {
        // يُحفظ المعالج ويُستدعى عند اكتمال أحداث الجلسة الخلفية
        // (انظر DownloadManager.urlSessionDidFinishEvents).
        AppDelegateBackgroundCompletion.handler = completionHandler
    }
}

@main
struct MediaClickApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    @StateObject private var downloadManager = DownloadManager.shared
    @StateObject private var libraryStore = LibraryStore.shared
    @StateObject private var languageManager = LanguageManager.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(downloadManager)
                .environmentObject(libraryStore)
                .environmentObject(languageManager)
                .preferredColorScheme(.dark)
                .environment(\.layoutDirection,
                             languageManager.isRTL ? .rightToLeft : .leftToRight)
                .environment(\.locale, Locale(identifier: languageManager.currentLanguage))
        }
    }
}
