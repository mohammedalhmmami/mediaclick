// DownloadManager.swift
// مدير التحميل — محرك التطبيق:
//  • التقاط فوري: لصق الرابط يبدأ التحميل فورًا (بلا انتظار).
//  • تمييز فوري للمنصة من الرابط نفسه (بلا أي اتصال شبكي).
//  • بدء فوري: المهمة تُنشأ على الخادم وتبدأ التنزيل هناك بالتوازي
//    (فيديو + صوت) دون انتظار فحص بطيء؛ والتقدم الحي يظهر من أول ثانية.
//  • ذاكرة: رابط نُزّل من قبل يُعرض من المكتبة فورًا بلا أي شبكة.
//  • تنزيل الملفات من الخادم إلى الجهاز عبر URLSession خلفية (تقدم حقيقي
//    بالبايتات)، مع إلغاء وإعادة محاولة، والواجهة تبقى مستجيبة تمامًا.

import Foundation
import Combine
import UIKit

/// حالة مهمة تحميل واحدة في التطبيق.
enum ActiveJobState {
    case starting        // أنشئت للتو — تقدم يظهر فورًا
    case processing      // الخادم يجهّز الملفات (فحص/تنزيل)
    case fetching        // جلب الملفات الجاهزة من الخادم إلى الجهاز
    case done
    case failed(String)  // رسالة عربية
}

/// مهمة تحميل نشطة (تظهر في الرئيسية بتقدم حي).
final class ActiveJob: ObservableObject, Identifiable {
    let id: String
    let sourceURL: String
    let platform: Platform
    @Published var state: ActiveJobState = .starting
    /// تقدم إجمالي 0...1 (تقدم الخادم ثم تقدم جلب الملفات).
    @Published var progress: Double = 0
    @Published var statusText: String = "جارٍ البدء…"
    var serverJobId: String?
    var result: DownloadResult?
    var errorMessage: String?
    var task: Task<Void, Never>?

    init(sourceURL: String, platform: Platform) {
        self.id = UUID().uuidString
        self.sourceURL = sourceURL
        self.platform = platform
    }

    var isActive: Bool {
        switch state {
        case .starting, .processing, .fetching: return true
        case .done, .failed: return false
        }
    }
}

/// مدير التحميل المركزي.
final class DownloadManager: NSObject, ObservableObject {
    static let shared = DownloadManager()

    @Published private(set) var activeJobs: [ActiveJob] = []
    @Published private(set) var recentResults: [DownloadResult] = []

    private let api = APIClient.shared
    private let library = LibraryStore.shared

    /// جلسة خلفية لجلب الملفات (تعمل حتى لو خرج التطبيق للخلفية).
    private lazy var backgroundSession: URLSession = {
        let config = URLSessionConfiguration.background(
            withIdentifier: "com.mediaclick.downloads")
        config.isDiscretionary = false
        config.sessionSendsLaunchEvents = true
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    /// تقدم كل ملف يُجلب حاليًا (مفتاحه اسم الملف).
    private var fetchProgress: [String: Double] = [:]
    private var fetchCompletions: [String: (Result<URL, Error>) -> Void] = [:]
    private let lock = NSLock()

    private override init() { super.init() }

    // MARK: - الذاكرة (رابط نُزّل من قبل)

    /// تطبيع الرابط للمقارنة (إزالة معلمات التتبع الشائعة وتوحيد المضيف).
    static func normalizedURL(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var parts = URLComponents(string: trimmed) else { return trimmed }
        parts.host = parts.host?.lowercased()
        // أزل معلمات تتبع لا تغيّر المحتوى
        let tracking = ["si", "utm_source", "utm_medium", "utm_campaign",
                        "utm_term", "utm_content", "fbclid", "igshid"]
        parts.queryItems = parts.queryItems?.filter { !tracking.contains($0.name) }
        return parts.url?.absoluteString ?? trimmed
    }

    /// ملفات سبق تحميلها من هذا الرابط (من المكتبة) أو nil.
    func cachedFiles(for urlString: String) -> [LibraryFile] {
        let norm = Self.normalizedURL(urlString)
        return library.files.filter { Self.normalizedURL($0.sourceURL) == norm }
    }

    // MARK: - بدء التحميل

    /// بدء تحميل رابط — يُستدعى فور اللصق (تلقائيًا) أو بضغطة زر تحميل.
    /// يرجع المهمة النشطة فورًا (للتقدم الحي)؛ والتنزيل يجري في الخلفية.
    @discardableResult
    func startDownload(urlString: String) -> ActiveJob? {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard PlatformDetector.isValidURL(trimmed) else { return nil }
        let platform = PlatformDetector.detect(from: trimmed)

        // 1) ذاكرة: رابط نُزّل من قبل يُعرض فورًا من المكتبة بلا أي شبكة.
        let cached = cachedFiles(for: trimmed)
        if !cached.isEmpty {
            let result = DownloadResult(
                id: UUID().uuidString, sourceURL: trimmed, platform: platform,
                title: cached.first?.title, duration: cached.first?.duration,
                notice: nil,
                videoFile: cached.first { $0.kind == .video },
                audioFile: cached.first { $0.kind == .audio },
                imageFiles: cached.filter { $0.kind == .image },
                createdAt: Date())
            DispatchQueue.main.async { self.recentResults.insert(result, at: 0) }
            return nil // لا مهمة نشطة — النتيجة ظهرت فورًا من الذاكرة
        }

        // 2) مهمة جديدة: تظهر فورًا بتقدم حي، والعمل يجري في الخلفية.
        let job = ActiveJob(sourceURL: trimmed, platform: platform)
        DispatchQueue.main.async { self.activeJobs.insert(job, at: 0) }
        job.task = Task { await self.runJob(job) }
        return job
    }

    /// إلغاء مهمة نشطة.
    func cancelJob(_ job: ActiveJob) {
        job.task?.cancel()
        DispatchQueue.main.async {
            self.activeJobs.removeAll { $0.id == job.id }
        }
    }

    /// إعادة محاولة مهمة فاشلة (نفس الرابط من جديد).
    func retryJob(sourceURL: String) {
        startDownload(urlString: sourceURL)
    }

    // MARK: - تنفيذ المهمة (خلفية)

    private func runJob(_ job: ActiveJob) async {
        // إنشاء المهمة على الخادم — يبدأ التنزيل هناك فورًا (بلا انتظار فحص).
        let serverJobId: String
        do {
            serverJobId = try await api.createJob(urlString: job.sourceURL)
        } catch {
            await fail(job, message: (error as? APIError)?.errorDescription
                       ?? "تعذّر الوصول إلى خادم التحميل.")
            return
        }
        job.serverJobId = serverJobId
        await update(job, state: .processing, progress: 0.02, text: "جارٍ تحميل الوسائط…")

        // استعلام الحالة بتقدم حي (كل ثانية) حتى الاكتمال أو الخطأ.
        //  • مهلة إجمالية صارمة (600ث) فلا يعلق الاستعلام إلى الأبد.
        //  • تراجع أسي عند أخطاء الشبكة العابرة (1ث، 2ث، 4ث، 8ث كحد أقصى).
        var serverJob: ServerJob?
        var lastProgress = 0.02
        let pollDeadline = Date().addingTimeInterval(600)
        var consecutiveErrors = 0
        while !Task.isCancelled {
            if Date() > pollDeadline {
                await fail(job, message: LanguageManager.shared.t("err_timeout"))
                return
            }
            do {
                let status = try await api.jobStatus(jobId: serverJobId)
                consecutiveErrors = 0
                serverJob = status
                // تقدم الخادم (0-100) يُحوَّل إلى 0-0.7 من التقدم الكلي
                let p = 0.02 + (Double(status.progress) / 100.0) * 0.68
                if p > lastProgress { lastProgress = p }
                let text: String
                switch status.status {
                case .queued: text = "في الانتظار…"
                case .probing: text = "جارٍ فحص الرابط…"
                case .downloading: text = "جارٍ تحميل الوسائط…"
                case .done: text = "تم التجهيز — جارٍ جلب الملفات…"
                case .error: text = "تعذّر"
                }
                await update(job, state: .processing, progress: lastProgress, text: text)
                if status.status == .done || status.status == .error { break }
            } catch {
                // خطأ شبكي عابر أثناء الاستعلام: تراجع أسي ثم أعد المحاولة
                consecutiveErrors += 1
                let backoff = min(pow(2.0, Double(min(consecutiveErrors, 3))), 8.0)
                try? await Task.sleep(nanoseconds: UInt64(backoff * 1_000_000_000))
                continue
            }
            try? await Task.sleep(nanoseconds: 1_000_000_000)
        }
        if Task.isCancelled {
            await update(job, state: .failed("أُلغي التحميل."), progress: job.progress, text: "أُلغي")
            return
        }
        guard let final = serverJob else {
            await fail(job, message: "تعذّر التحميل — حاول مجددًا.")
            return
        }
        if final.status == .error {
            await fail(job, message: ServerErrorMessage.arabic(for: final.error))
            return
        }

        // جلب الملفات الجاهزة من الخادم إلى الجهاز (تقدم حقيقي بالبايتات).
        await update(job, state: .fetching, progress: 0.72, text: "جارٍ جلب الملفات إلى جهازك…")
        let mediaFiles = final.files.filter { $0.kind != .thumbnail }
        let thumbFile = final.files.first { $0.kind == .thumbnail }
        var videoEntry: LibraryFile?
        var audioEntry: LibraryFile?
        var imageEntries: [LibraryFile] = []
        let total = max(mediaFiles.count, 1)
        var fetched = 0
        for file in mediaFiles {
            if Task.isCancelled { break }
            let remote = api.fileURL(jobId: serverJobId, name: file.name)
            do {
                let local = try await fetchFile(remote, name: file.name, job: job)
                // مصغّرة الفيديو: من الخادم إن وُجدت، وإلا توليد محلي
                // حقيقي من ملف الفيديو نفسه قبل نقله إلى المكتبة.
                var thumbLocal: URL?
                if file.kind == .video {
                    if let thumb = thumbFile {
                        let thumbRemote = api.fileURL(jobId: serverJobId, name: thumb.name)
                        thumbLocal = try? await fetchFile(thumbRemote, name: thumb.name, job: job)
                    }
                    if thumbLocal == nil {
                        thumbLocal = ThumbnailGenerator.videoThumbnail(for: local)
                    }
                }
                let entry = library.addFile(
                    from: local, name: file.name, kind: file.kind,
                    platform: job.platform, sourceURL: job.sourceURL,
                    title: final.title, duration: final.duration,
                    thumbnailURL: thumbLocal)
                switch file.kind {
                case .video: videoEntry = entry
                case .audio: audioEntry = entry
                case .image: imageEntries.append(entry)
                case .thumbnail: break
                }
            } catch {
                // ملف واحد فشل: أكمل البقية ولا تفشل المهمة كلها
                continue
            }
            fetched += 1
            let p = 0.72 + (Double(fetched) / Double(total)) * 0.28
            await update(job, state: .fetching, progress: p,
                         text: "جارٍ جلب الملفات إلى جهازك… (\(fetched)/\(total))")
        }
        if Task.isCancelled { return }
        guard videoEntry != nil || audioEntry != nil || !imageEntries.isEmpty else {
            await fail(job, message: "تعذّر جلب الملفات — حاول مجددًا.")
            return
        }
        let result = DownloadResult(
            id: UUID().uuidString, sourceURL: job.sourceURL, platform: job.platform,
            title: final.title, duration: final.duration, notice: final.notice,
            videoFile: videoEntry, audioFile: audioEntry,
            imageFiles: imageEntries.sorted { $0.name < $1.name }, createdAt: Date())
        job.result = result
        await update(job, state: .done, progress: 1.0, text: "اكتمل")
        DispatchQueue.main.async {
            self.recentResults.insert(result, at: 0)
            self.activeJobs.removeAll { $0.id == job.id }
        }
    }

    // MARK: - أدوات داخلية

    @MainActor
    private func update(_ job: ActiveJob, state: ActiveJobState, progress: Double, text: String) {
        job.state = state
        job.progress = min(max(progress, 0), 1)
        job.statusText = text
    }

    @MainActor
    private func fail(_ job: ActiveJob, message: String) {
        job.errorMessage = message
        job.state = .failed(message)
        job.statusText = message
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
            self.activeJobs.removeAll { $0.id == job.id }
        }
    }

    /// جلب ملف واحد من الخادم عبر الجلسة الخلفية مع تقدم حي.
    /// كل جلب له معرّف فريد (بلا تعارض بين مهمتين تنزّلان نفس الاسم).
    private func fetchFile(_ url: URL, name: String, job: ActiveJob) async throws -> URL {
        let fetchId = UUID().uuidString
        return try await withCheckedThrowingContinuation { continuation in
            lock.lock()
            fetchCompletions[fetchId] = { result in
                continuation.resume(with: result)
            }
            lock.unlock()
            // تنزيل الملف بترويسة المصادقة — الخادم يرفض /api/file بلا التوكن.
            var request = URLRequest(url: url)
            request.setValue(APIClient.shared.token, forHTTPHeaderField: "X-MediaClick-Token")
            let task = backgroundSession.downloadTask(with: request)
            task.taskDescription = fetchId
            task.resume()
        }
    }
}

// MARK: - URLSessionDownloadDelegate (تقدم حقيقي بالبايتات)

extension DownloadManager: URLSessionDownloadDelegate {
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0,
              let fetchId = downloadTask.taskDescription else { return }
        lock.lock()
        fetchProgress[fetchId] = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        lock.unlock()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        guard let fetchId = downloadTask.taskDescription else { return }
        lock.lock()
        let completion = fetchCompletions.removeValue(forKey: fetchId)
        fetchProgress.removeValue(forKey: fetchId)
        lock.unlock()
        // انقل الملف المؤقت إلى ملف مؤقت دائم قبل انتهاء الجلسة
        let dest = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
            completion?(.success(dest))
        } catch {
            completion?(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error,
              let fetchId = task.taskDescription else { return }
        lock.lock()
        let completion = fetchCompletions.removeValue(forKey: fetchId)
        fetchProgress.removeValue(forKey: fetchId)
        lock.unlock()
        completion?(.failure(error))
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        // يُستدعى عند اكتمال أحداث الجلسة الخلفية بعد عودة التطبيق للواجهة.
        DispatchQueue.main.async {
            if let handler = AppDelegateBackgroundCompletion.handler {
                AppDelegateBackgroundCompletion.handler = nil
                handler()
            }
        }
    }
}

/// حامل معالج إكمال الجلسة الخلفية (يُستدعى من AppDelegate).
enum AppDelegateBackgroundCompletion {
    static var handler: (() -> Void)?
}
