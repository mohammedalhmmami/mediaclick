// DownloadManager.swift
// مدير التحميل — محرك التطبيق:
//  • التقاط فوري: لصق الرابط يبدأ التحميل فورًا (بلا انتظار).
//  • تمييز فوري للمنصة من الرابط نفسه (بلا أي اتصال شبكي).
//  • بدء فوري: المهمة تُنشأ على الخادم وتبدأ التنزيل هناك بالتوازي
//    (فيديو + صوت) دون انتظار فحص بطيء؛ والتقدم الحي يظهر من أول ثانية.
//  • ذاكرة: رابط نُزّل من قبل يُعرض من المكتبة فورًا بلا أي شبكة.
//  • تنزيل الملفات من الخادم إلى الجهاز عبر URLSession خلفية (تقدم حقيقي
//    بالبايتات)، مع إلغاء وإعادة محاولة، والواجهة تبقى مستجيبة تمامًا.
//  • جلب مبكر (تمرير تدفقي): كل ملف يظهر على الخادم يُجلب فورًا
//    أثناء عمل الخادم — الملف النامي يُبثّ حتى نهايته النظيفة —
//    فتصل الملفات للجوال قبل اكتمال المهمة، ومرحلة الجلب النهائية
//    تجدها جاهزة في صندوق الوارد بلا إعادة تنزيل.
//  • التحميل يستمر بعد الخروج من التطبيق: الجلسة الخلفية للنظام تواصل
//    التنزيل، وحالة المهمة والملفات المكتملة محفوظة على الجهاز، فعند
//    إعادة فتح التطبيق (أو إطلاقه في الخلفية لحدث الجلسة) تُستأنف
//    المهمة من حيث توقفت بلا إعادة تنزيل ما اكتمل، وملف انقطع
//    يُستأنف من منتصفه ببيانات الاستئناف (بحد 3 محاولات) أو يُعاد
//    تنزيله من جديد. وعند اكتمال التحميل والتطبيق خارج الواجهة
//    يصل إشعار «تم التحميل».

import Foundation
import Combine
import UIKit
import UserNotifications

/// حالة مهمة تحميل واحدة في التطبيق.
enum ActiveJobState {
    case starting        // أنشئت للتو — تقدم يظهر فورًا
    case processing      // الخادم يجهّز الملفات (فحص/تنزيل)
    case fetching        // جلب الملفات الجاهزة من الخادم إلى الجهاز
    case done
    case failed(String)  // رسالة عربية
}

/// مهمة تحميل نشطة (تظهر في الرئيسية بتقدم حي).
final class ActiveJob: ObservableObject, Identifiable {
    let id: String
    let sourceURL: String
    let platform: Platform
    @Published var state: ActiveJobState = .starting
    /// تقدم إجمالي 0...1 (تقدم الخادم ثم تقدم جلب الملفات).
    @Published var progress: Double = 0
    @Published var statusText: String = "جارٍ البدء…"
    var serverJobId: String?
    var result: DownloadResult?
    var errorMessage: String?
    var task: Task<Void, Never>?
    /// مهام الجلب المبكر الجارية (تُلغى مع المهمة).
    var earlyTasks: [Task<Void, Never>] = []
    /// معرّف مهمة الخلفية — يمنح التطبيق وقتًا إضافيًا لإنهاء
    /// التحميل بعد خروج المستخدم من التطبيق.
    var bgTaskID: UIBackgroundTaskIdentifier = .invalid

    init(sourceURL: String, platform: Platform) {
        self.id = UUID().uuidString
        self.sourceURL = sourceURL
        self.platform = platform
    }

    var isActive: Bool {
        switch state {
        case .starting, .processing, .fetching: return true
        case .done, .failed: return false
        }
    }
}

/// سجل مهمة معلّقة (محفوظ — يستأنف بعد إغلاق التطبيق أو إنهائه).
private struct PendingJobRecord: Codable {
    var serverJobId: String
    var sourceURL: String
    var platformRaw: String
    var title: String?
    var duration: Double?
    var expectedFiles: [ExpectedFile]
    var createdAt: Date

    struct ExpectedFile: Codable {
        var name: String
        var kind: MediaKind
    }
}

/// سجل جلب ملف واحد (محفوظ — يربط مهمة التنزيل الخلفية بملفها
/// حتى بعد إعادة إطلاق التطبيق).
private struct FetchRecord: Codable {
    var fetchId: String
    var serverJobId: String
    var fileName: String
    var kind: MediaKind
    var resumeCount: Int
    /// true إن كان الملف ما زال ينمو على الخادم وقت بدء الجلب —
    /// عندها لا تُستخدم بيانات الاستئناف أبدًا (الخادم يتجاهل Range
    /// للملف النامي ويعيد بثّه من البداية، فالاستئناف يفسد الملف).
    var growing: Bool = false
}

/// مدير التحميل المركزي.
final class DownloadManager: NSObject, ObservableObject {
    static let shared = DownloadManager()

    @Published private(set) var activeJobs: [ActiveJob] = []
    @Published private(set) var recentResults: [DownloadResult] = []

    private let api = APIClient.shared
    private let library = LibraryStore.shared

    /// جلسة خلفية لجلب الملفات (تعمل حتى لو خرج التطبيق للخلفية).
    private lazy var backgroundSession: URLSession = {
        let config = URLSessionConfiguration.background(
            withIdentifier: "com.mediaclick.downloads")
        config.isDiscretionary = false
        config.sessionSendsLaunchEvents = true
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()

    /// تقدم كل ملف يُجلب حاليًا (مفتاحه اسم الملف).
    private var fetchProgress: [String: Double] = [:]
    /// إكمالات الجلب المعلّقة (قد ينتظر أكثر من مستدعٍ نفس الملف).
    private var fetchCompletions: [String: [(Result<URL, Error>) -> Void]] = [:]
    /// أسماء الملفات التي يجري جلبها مبكرًا الآن (لمنع التكرار).
    private var earlyFetching: Set<String> = []
    private let lock = NSLock()

    // MARK: - السجلات المحفوظة (استئناف بعد إنهاء التطبيق)

    private static let pendingJobsKey = "mc.pendingJobs"
    private static let completedFetchesKey = "mc.completedFetches"
    private static let fetchRecordsKey = "mc.fetchRecords"

    /// مهام معلّقة (معرّف الخادم ← السجل).
    private var pendingJobs: [String: PendingJobRecord] = [:]
    /// ملفات اكتمل جلبها (معرّف الخادم ← اسم الملف ← مسار صندوق الوارد).
    private var completedFetches: [String: [String: String]] = [:]
    /// سجلات جلب جارية (معرّف الجلب ← السجل).
    private var fetchRecords: [String: FetchRecord] = [:]

    private func loadStore<T: Decodable>(_ key: String, as type: T.Type) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(type, from: data)
    }

    private func saveStore<T: Encodable>(_ key: String, _ value: T) {
        if let data = try? JSONEncoder().encode(value) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    /// حفظ كل السجلات (يُستدعى تحت القفل بعد كل تغيير).
    private func persistStores() {
        saveStore(Self.pendingJobsKey, pendingJobs)
        saveStore(Self.completedFetchesKey, completedFetches)
        saveStore(Self.fetchRecordsKey, fetchRecords)
    }

    /// مجلد صندوق الوارد الدائم (يبقى بعد إنهاء التطبيق — خلاف المؤقت).
    private var inboxDirectory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory,
                                            in: .userDomainMask).first!
        let dir = base.appendingPathComponent("MediaClickInbox", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private func inboxURL(serverJobId: String, fileName: String) -> URL {
        let safe = fileName.replacingOccurrences(of: "/", with: "_")
        return inboxDirectory.appendingPathComponent("\(serverJobId)_\(safe)")
    }

    /// حذف ملفات صندوق الوارد الخاصة بمهمة (بعد نقلها إلى المكتبة).
    private func cleanInbox(for serverJobId: String) {
        let dir = inboxDirectory
        let prefix = "\(serverJobId)_"
        guard let items = try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: nil) else { return }
        for item in items where item.lastPathComponent.hasPrefix(prefix) {
            try? FileManager.default.removeItem(at: item)
        }
    }

    private override init() {
        super.init()
        if let v: [String: PendingJobRecord] = loadStore(Self.pendingJobsKey,
            as: [String: PendingJobRecord].self) { pendingJobs = v }
        if let v: [String: [String: String]] = loadStore(Self.completedFetchesKey,
            as: [String: [String: String]].self) { completedFetches = v }
        if let v: [String: FetchRecord] = loadStore(Self.fetchRecordsKey,
            as: [String: FetchRecord].self) { fetchRecords = v }
        resumePendingWork()
    }

    /// إيقاظ الجلسة الخلفية واستئناف المهام المعلّقة — يُستدعى عند بدء
    /// التطبيق وفي كل حدث خلفية من النظام (انظر AppDelegate).
    func warmUpBackgroundSession() {
        _ = backgroundSession
        resumePendingWork()
    }

    /// استئناف المهام المعلّقة من جلسة سابقة (بلا تكرار).
    private func resumePendingWork() {
        _ = backgroundSession
        // نظّف سجلات أقدم من ساعة (مهمة الخادم نفسها تنتهي صلاحيتها).
        let now = Date()
        lock.lock()
        pendingJobs = pendingJobs.filter { now.timeIntervalSince($0.value.createdAt) < 3600 }
        persistStores()
        let records = Array(pendingJobs.values)
        lock.unlock()
        // ألغِ مهام تنزيل يتيمة (بلا سجل جلب ولا مستدعٍ) حتى لا تبقى عالقة.
        backgroundSession.getAllTasks { tasks in
            for task in tasks {
                guard let fid = task.taskDescription else { continue }
                self.lock.lock()
                let orphaned = self.fetchRecords[fid] == nil
                    && self.fetchCompletions[fid] == nil
                self.lock.unlock()
                if orphaned { task.cancel() }
            }
        }
        for record in records {
            if activeJobs.contains(where: { $0.serverJobId == record.serverJobId }) { continue }
            let job = ActiveJob(sourceURL: record.sourceURL,
                                platform: Platform(rawValue: record.platformRaw) ?? .unknown)
            job.serverJobId = record.serverJobId
            job.state = .processing
            job.statusText = "جارٍ استئناف التحميل…"
            beginBackgroundTask(for: job)
            insertActiveJob(job)
            job.task = Task { await self.runJob(job, resumeServerJobId: record.serverJobId) }
        }
    }

    // MARK: - الذاكرة (رابط نُزّل من قبل)

    /// تطبيع الرابط للمقارنة (إزالة معلمات التتبع الشائعة وتوحيد المضيف).
    static func normalizedURL(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var parts = URLComponents(string: trimmed) else { return trimmed }
        parts.host = parts.host?.lowercased()
        // أزل معلمات تتبع لا تغيّر المحتوى
        let tracking = ["si", "utm_source", "utm_medium", "utm_campaign",
                        "utm_term", "utm_content", "fbclid", "igshid"]
        parts.queryItems = parts.queryItems?.filter { !tracking.contains($0.name) }
        return parts.url?.absoluteString ?? trimmed
    }

    /// ملفات سبق تحميلها من هذا الرابط (من المكتبة) أو nil.
    func cachedFiles(for urlString: String) -> [LibraryFile] {
        let norm = Self.normalizedURL(urlString)
        return library.files.filter { Self.normalizedURL($0.sourceURL) == norm }
    }

    // MARK: - بدء التحميل

    /// بدء تحميل رابط — يُستدعى فور اللصق (تلقائيًا) أو بضغطة زر تحميل.
    /// يرجع المهمة النشطة فورًا (للتقدم الحي)؛ والتنزيل يجري في الخلفية.
    @discardableResult
    func startDownload(urlString: String) -> ActiveJob? {
        requestNotificationAuthorizationIfNeeded()
        // طبّع الرابط أولًا: يقبل أي صيغة (بلا مخطط، داخل نص، بعلامات زائدة).
        guard let trimmed = PlatformDetector.normalizeURL(urlString) else { return nil }
        let platform = PlatformDetector.detect(from: trimmed)

        // 1) ذاكرة: رابط نُزّل من قبل يُعرض فورًا من المكتبة بلا أي شبكة.
        let cached = cachedFiles(for: trimmed)
        if !cached.isEmpty {
            let result = DownloadResult(
                id: UUID().uuidString, sourceURL: trimmed, platform: platform,
                title: cached.first?.title, duration: cached.first?.duration,
                notice: nil,
                videoFile: cached.first { $0.kind == .video },
                audioFile: cached.first { $0.kind == .audio },
                imageFiles: cached.filter { $0.kind == .image },
                createdAt: Date())
            DispatchQueue.main.async { self.recentResults = [result] }
            return nil // لا مهمة نشطة — النتيجة ظهرت فورًا من الذاكرة
        }

        // 2) مهمة جديدة: تظهر فورًا بتقدم حي، والعمل يجري في الخلفية.
        let job = ActiveJob(sourceURL: trimmed, platform: platform)
        beginBackgroundTask(for: job)
        insertActiveJob(job)
        job.task = Task { await self.runJob(job, resumeServerJobId: nil) }
        return job
    }

    /// إلغاء مهمة نشطة.
    func cancelJob(_ job: ActiveJob) {
        job.task?.cancel()
        for t in job.earlyTasks { t.cancel() }
        job.earlyTasks.removeAll()
        if let sid = job.serverJobId {
            cancelFetches(for: sid)
            lock.lock()
            pendingJobs.removeValue(forKey: sid)
            completedFetches.removeValue(forKey: sid)
            persistStores()
            lock.unlock()
            cleanInbox(for: sid)
        }
        endBackgroundTask(for: job)
        DispatchQueue.main.async {
            self.activeJobs.removeAll { $0.id == job.id }
        }
    }

    /// إعادة محاولة مهمة فاشلة (نفس الرابط من جديد).
    func retryJob(sourceURL: String) {
        startDownload(urlString: sourceURL)
    }

    /// إدراج مهمة نشطة في القائمة (فوري إن كنا في الخيط الرئيسي).
    private func insertActiveJob(_ job: ActiveJob) {
        if Thread.isMainThread {
            activeJobs.insert(job, at: 0)
        } else {
            DispatchQueue.main.async { self.activeJobs.insert(job, at: 0) }
        }
    }

    /// بدء مهمة خلفية للنظام (وقت إضافي بعد خروج المستخدم من التطبيق).
    private func beginBackgroundTask(for job: ActiveJob) {
        job.bgTaskID = UIApplication.shared.beginBackgroundTask { [weak self, weak job] in
            guard let self = self, let job = job else { return }
            self.endBackgroundTask(for: job)
        }
    }

    /// إنهاء مهمة الخلفية (بلا ضرر إن لم تكن بدأت).
    private func endBackgroundTask(for job: ActiveJob) {
        lock.lock()
        let id = job.bgTaskID
        job.bgTaskID = .invalid
        lock.unlock()
        if id != .invalid {
            UIApplication.shared.endBackgroundTask(id)
        }
    }

    /// إلغاء مهام تنزيل جارية لمهمة خادم معيّنة.
    private func cancelFetches(for serverJobId: String) {
        backgroundSession.getAllTasks { tasks in
            for task in tasks {
                guard let fid = task.taskDescription else { continue }
                self.lock.lock()
                let match = self.fetchRecords[fid]?.serverJobId == serverJobId
                self.lock.unlock()
                if match { task.cancel() }
            }
        }
    }

    // MARK: - تنفيذ المهمة (خلفية)

    private func runJob(_ job: ActiveJob, resumeServerJobId: String? = nil) async {
        defer { endBackgroundTask(for: job) }
        let isResume = resumeServerJobId != nil
        // إنشاء المهمة على الخادم — يبدأ التنزيل هناك فورًا (بلا انتظار فحص).
        // عند الاستئناف نستخدم معرّف الخادم المحفوظ بدل إنشاء مهمة جديدة.
        let serverJobId: String
        if let resumed = resumeServerJobId {
            serverJobId = resumed
            lock.lock()
            if pendingJobs[serverJobId] == nil {
                pendingJobs[serverJobId] = PendingJobRecord(
                    serverJobId: serverJobId, sourceURL: job.sourceURL,
                    platformRaw: job.platform.rawValue, title: nil, duration: nil,
                    expectedFiles: [], createdAt: Date())
                persistStores()
            }
            lock.unlock()
        } else {
            do {
                serverJobId = try await api.createJob(urlString: job.sourceURL)
            } catch {
                await fail(job, message: (error as? APIError)?.errorDescription
                           ?? "تعذّر الوصول إلى خادم التحميل.")
                return
            }
            lock.lock()
            pendingJobs[serverJobId] = PendingJobRecord(
                serverJobId: serverJobId, sourceURL: job.sourceURL,
                platformRaw: job.platform.rawValue, title: nil, duration: nil,
                expectedFiles: [], createdAt: Date())
            persistStores()
            lock.unlock()
        }
        job.serverJobId = serverJobId
        await update(job, state: .processing, progress: 0.02, text: "جارٍ تحميل الوسائط…")

        // استعلام الحالة بتقدم حي (كل ثانية) حتى الاكتمال أو الخطأ.
        //  • ميزانية 600 استعلامًا من وقت التشغيل الفعلي (لا ساعة حائط)
        //    فلا تنتهي المهلة لمجرد أن التطبيق كان موقوفًا في الخلفية.
        //  • تراجع أسي عند أخطاء الشبكة العابرة (1ث، 2ث، 4ث، 8ث كحد أقصى).
        var serverJob: ServerJob?
        var lastProgress = 0.02
        var polls = 0
        var consecutiveErrors = 0
        while !Task.isCancelled {
            polls += 1
            if polls > 600 {
                // انتهت المهلة: السجل المحفوظ يُبقي المهمة لتُستأنف عند الفتح التالي.
                if isResume {
                    silentEnd(job)
                } else {
                    await fail(job, message: LanguageManager.shared.t("err_timeout"))
                }
                return
            }
            do {
                let status = try await api.jobStatus(jobId: serverJobId)
                consecutiveErrors = 0
                serverJob = status
                // جلب مبكر: أي ملف ظهر على الخادم يُجلب فورًا أثناء
                // عمل الخادم (تمرير تدفقي)، فيصل الملف للجوال قبل
                // اكتمال المهمة بثوانٍ.
                startEarlyFetches(status: status, job: job)
                // تقدم الخادم (0-100) يُحوَّل إلى 0-0.7 من التقدم الكلي
                let p = 0.02 + (Double(status.progress) / 100.0) * 0.68
                if p > lastProgress { lastProgress = p }
                let text: String
                switch status.status {
                case .queued: text = "في الانتظار…"
                case .probing: text = "جارٍ فحص الرابط…"
                case .downloading: text = "جارٍ تحميل الوسائط…"
                case .done: text = "تم التجهيز — جارٍ جلب الملفات…"
                case .error: text = "تعذّر"
                }
                await update(job, state: .processing, progress: lastProgress, text: text)
                if status.status == .done {
                    // احفظ قائمة الملفات المتوقعة (لاكتشاف الاكتمال بعد إعادة الإطلاق).
                    lock.lock()
                    if var rec = pendingJobs[serverJobId] {
                        rec.title = status.title
                        rec.duration = status.duration
                        rec.expectedFiles = status.files.map {
                            PendingJobRecord.ExpectedFile(name: $0.name, kind: $0.kind)
                        }
                        pendingJobs[serverJobId] = rec
                        persistStores()
                    }
                    lock.unlock()
                }
                if status.status == .done || status.status == .error { break }
            } catch {
                // خطأ شبكي عابر أثناء الاستعلام: تراجع أسي ثم أعد المحاولة
                consecutiveErrors += 1
                let backoff = min(pow(2.0, Double(min(consecutiveErrors, 3))), 8.0)
                try? await Task.sleep(nanoseconds: UInt64(backoff * 1_000_000_000))
                continue
            }
            try? await Task.sleep(nanoseconds: 1_000_000_000)
        }
        if Task.isCancelled {
            await update(job, state: .failed("أُلغي التحميل."), progress: job.progress, text: "أُلغي")
            return
        }
        guard let final = serverJob else {
            if isResume { silentEnd(job) } else {
                await fail(job, message: "تعذّر التحميل — حاول مجددًا.")
            }
            return
        }
        if final.status == .error {
            // خطأ نهائي من الخادم (رابط غير صالح/دخول مطلوب): المهمة ميتة.
            // (تُمسح أيضًا ملفات الجلب المبكر اليتيمة من صندوق الوارد.)
            lock.lock()
            pendingJobs.removeValue(forKey: serverJobId)
            completedFetches.removeValue(forKey: serverJobId)
            persistStores()
            lock.unlock()
            cleanInbox(for: serverJobId)
            await fail(job, message: ServerErrorMessage.arabic(for: final.error))
            return
        }

        // جلب الملفات الجاهزة من الخادم إلى الجهاز (تقدم حقيقي بالبايتات).
        await update(job, state: .fetching, progress: 0.72, text: "جارٍ جلب الملفات إلى جهازك…")
        let mediaFiles = final.files.filter { $0.kind != .thumbnail }
        let thumbFile = final.files.first { $0.kind == .thumbnail }
        var videoEntry: LibraryFile?
        var audioEntry: LibraryFile?
        var imageEntries: [LibraryFile] = []
        let total = max(mediaFiles.count, 1)
        var fetched = 0
        for file in mediaFiles {
            if Task.isCancelled { break }
            let remote = api.fileURL(jobId: serverJobId, name: file.name)
            // إعادة محاولة كل ملف حتى 3 مرات قبل تخطّيه (بلا أخطاء عابرة).
            var local: URL?
            for attempt in 1...3 {
                if Task.isCancelled { break }
                do {
                    local = try await fetchFile(remote, name: file.name,
                                                kind: file.kind, job: job)
                    break
                } catch {
                    if attempt < 3 {
                        try? await Task.sleep(nanoseconds: 1_000_000_000)
                    }
                }
            }
            guard let localURL = local else { continue }
            do {
                // مصغّرة الفيديو: من الخادم إن وُجدت، وإلا توليد محلي
                // حقيقي من ملف الفيديو نفسه قبل نقله إلى المكتبة.
                var thumbLocal: URL?
                if file.kind == .video {
                    if let thumb = thumbFile {
                        let thumbRemote = api.fileURL(jobId: serverJobId, name: thumb.name)
                        thumbLocal = try? await fetchFile(thumbRemote, name: thumb.name,
                                                          kind: .thumbnail, job: job)
                    }
                    if thumbLocal == nil {
                        thumbLocal = ThumbnailGenerator.videoThumbnail(for: localURL)
                    }
                }
                let entry = library.addFile(
                    from: localURL, name: file.name, kind: file.kind,
                    platform: job.platform, sourceURL: job.sourceURL,
                    title: final.title, duration: final.duration,
                    thumbnailURL: thumbLocal)
                switch file.kind {
                case .video: videoEntry = entry
                case .audio: audioEntry = entry
                case .image: imageEntries.append(entry)
                case .thumbnail: break
                }
            } catch {
                // ملف واحد فشل: أكمل البقية ولا تفشل المهمة كلها
                continue
            }
            fetched += 1
            let p = 0.72 + (Double(fetched) / Double(total)) * 0.28
            await update(job, state: .fetching, progress: p,
                         text: "جارٍ جلب الملفات إلى جهازك… (\(fetched)/\(total))")
        }
        if Task.isCancelled { return }
        guard videoEntry != nil || audioEntry != nil || !imageEntries.isEmpty else {
            // الملفات ما زالت على الخادم: السجل المحفوظ يُبقي المهمة
            // لتُستأنف عند الفتح التالي بدل إظهار خطأ نهائي.
            if isResume { silentEnd(job) } else {
                await fail(job, message: "تعذّر جلب الملفات — حاول مجددًا.")
            }
            return
        }
        let result = DownloadResult(
            id: UUID().uuidString, sourceURL: job.sourceURL, platform: job.platform,
            title: final.title, duration: final.duration, notice: final.notice,
            videoFile: videoEntry, audioFile: audioEntry,
            imageFiles: imageEntries.sorted { $0.name < $1.name }, createdAt: Date())
        job.result = result
        await update(job, state: .done, progress: 1.0, text: "اكتمل")
        DispatchQueue.main.async {
            // الصفحة الرئيسية تعرض آخر تحميل فقط — النتائج السابقة
            // تُستبدل بالجديدة (الملفات نفسها تبقى في «ملفاتي»).
            self.recentResults = [result]
            self.activeJobs.removeAll { $0.id == job.id }
        }
        // نظّف سجلات المهمة وملفات صندوق الوارد (أصبحت في المكتبة).
        lock.lock()
        pendingJobs.removeValue(forKey: serverJobId)
        completedFetches.removeValue(forKey: serverJobId)
        persistStores()
        lock.unlock()
        cleanInbox(for: serverJobId)
        // إشعار «تم التحميل» إن كان التطبيق خارج الواجهة.
        postCompletionNotification(serverJobId: serverJobId,
                                   title: final.title ?? job.platform.displayName)
    }

    // MARK: - الجلب المبكر (التمرير التدفقي)

    /// بدء جلب مبكر لكل ملف ظهر في حالة الخادم ولم يُجلب بعد.
    /// يُستدعى بعد كل استعلام حالة ناجح؛ والجلب يجري بالتوازي
    /// مع عمل الخادم: الملف النامي يُبثّ مجزّأً حتى نهايته
    /// النظيفة، والملف المكتمل يُجلب فورًا. ملف أُرسل كاملًا
    /// وحُذف من الخادم (served) لا يُطلب مجددًا أبدًا.
    private func startEarlyFetches(status: ServerJob, job: ActiveJob) {
        guard let serverJobId = job.serverJobId else { return }
        for file in status.files {
            lock.lock()
            let haveLocal = completedFetches[serverJobId]?[file.name] != nil
            let skip = haveLocal
                || earlyFetching.contains(file.name)
                || file.served
            if !skip { earlyFetching.insert(file.name) }
            lock.unlock()
            if skip { continue }
            let t = Task { [weak self, weak job] in
                guard let self = self, let job = job else { return }
                await self.earlyFetchFile(file: file, job: job)
                self.lock.lock()
                self.earlyFetching.remove(file.name)
                self.lock.unlock()
            }
            job.earlyTasks.append(t)
        }
    }

    /// جلب مبكر لملف واحد (حتى 3 محاولات، بلا فشل ظاهر —
    /// مرحلة الجلب النهائية بعد اكتمال المهمة تعيد المحاولة
    /// لأي ملف لم يصل بعد).
    private func earlyFetchFile(file: ServerFile, job: ActiveJob) async {
        guard let serverJobId = job.serverJobId else { return }
        let remote = api.fileURL(jobId: serverJobId, name: file.name)
        for attempt in 1...3 {
            if Task.isCancelled { return }
            do {
                _ = try await fetchFile(remote, name: file.name,
                                        kind: file.kind, job: job,
                                        growing: file.growing)
                return
            } catch {
                if attempt < 3 {
                    try? await Task.sleep(nanoseconds: 1_000_000_000)
                }
            }
        }
    }

    // MARK: - أدوات داخلية

    @MainActor
    private func update(_ job: ActiveJob, state: ActiveJobState, progress: Double, text: String) {
        job.state = state
        job.progress = min(max(progress, 0), 1)
        job.statusText = text
    }

    @MainActor
    private func fail(_ job: ActiveJob, message: String) {
        job.errorMessage = message
        job.state = .failed(message)
        job.statusText = message
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
            self.activeJobs.removeAll { $0.id == job.id }
        }
    }

    /// إنهاء صامت لمهمة مستأنفة (بلا رسالة خطأ — ستُعاد المحاولة
    /// تلقائيًا عند الفتح التالي من السجل المحفوظ).
    private func silentEnd(_ job: ActiveJob) {
        DispatchQueue.main.async {
            self.activeJobs.removeAll { $0.id == job.id }
        }
    }

    /// جلب ملف واحد من الخادم عبر الجلسة الخلفية مع تقدم حي.
    ///  • إن اكتمل تنزيله سابقًا (محفوظ في صندوق الوارد) يُرجع فورًا بلا شبكة.
    ///  • إن كانت مهمة تنزيله جارية أصلًا يُرفق بها بدل إنشاء مهمة مكررة.
    ///  • كل جلب له معرّف فريد (بلا تعارض بين مهمتين تنزّلان نفس الاسم).
    ///  • growing=true: الملف ما زال ينمو على الخادم — يُبثّ من البداية
    ///    حتى نهايته النظيفة، ولا تُستخدم بيانات الاستئناف أبدًا.
    private func fetchFile(_ url: URL, name: String, kind: MediaKind, job: ActiveJob,
                           growing: Bool = false) async throws -> URL {
        guard let serverJobId = job.serverJobId else { throw APIError.badResponse }
        // 1) مكتمل سابقًا؟ أرجعه من صندوق الوارد بلا أي شبكة.
        // (يُفحص الملف نفسه أيضًا — إن ضاع السجل في إغلاق مفاجئ
        // يبقى ملف صندوق الوارد دليلًا كافيًا على اكتماله.)
        lock.lock()
        let donePath = completedFetches[serverJobId]?[name]
        lock.unlock()
        if let p = donePath {
            let local = URL(fileURLWithPath: p)
            if FileManager.default.fileExists(atPath: local.path) { return local }
        }
        let inboxLocal = inboxURL(serverJobId: serverJobId, fileName: name)
        if FileManager.default.fileExists(atPath: inboxLocal.path) {
            lock.lock()
            completedFetches[serverJobId, default: [:]][name] = inboxLocal.path
            persistStores()
            lock.unlock()
            return inboxLocal
        }
        // 2) مهمة جارية لنفس الملف؟ أرفق بها.
        if let existingId = await inFlightFetchId(serverJobId: serverJobId, fileName: name) {
            return try await withCheckedThrowingContinuation { continuation in
                lock.lock()
                fetchCompletions[existingId, default: []].append { result in
                    continuation.resume(with: result)
                }
                lock.unlock()
            }
        }
        // 3) مهمة تنزيل جديدة.
        let fetchId = UUID().uuidString
        lock.lock()
        fetchRecords[fetchId] = FetchRecord(fetchId: fetchId, serverJobId: serverJobId,
                                            fileName: name, kind: kind, resumeCount: 0,
                                            growing: growing)
        persistStores()
        lock.unlock()
        return try await withCheckedThrowingContinuation { continuation in
            lock.lock()
            fetchCompletions[fetchId, default: []].append { result in
                continuation.resume(with: result)
            }
            lock.unlock()
            // تنزيل الملف بترويسة المصادقة — الخادم يرفض /api/file بلا التوكن.
            var request = URLRequest(url: url)
            request.setValue(APIClient.shared.token, forHTTPHeaderField: "X-MediaClick-Token")
            let task = backgroundSession.downloadTask(with: request)
            task.taskDescription = fetchId
            task.resume()
        }
    }

    /// معرّف جلب مهمة تنزيل جارية لنفس ملف المهمة، أو nil.
    private func inFlightFetchId(serverJobId: String, fileName: String) async -> String? {
        await withCheckedContinuation { (c: CheckedContinuation<String?, Never>) in
            backgroundSession.getAllTasks { tasks in
                self.lock.lock()
                defer { self.lock.unlock() }
                for task in tasks {
                    guard let fid = task.taskDescription,
                          let rec = self.fetchRecords[fid],
                          rec.serverJobId == serverJobId,
                          rec.fileName == fileName else { continue }
                    c.resume(returning: fid)
                    return
                }
                c.resume(returning: nil)
            }
        }
    }

    /// فشل جلب: أزِل سجله وأنهِ كل المستدعين بالخطأ.
    private func failFetch(fetchId: String, error: Error) {
        lock.lock()
        let completions = fetchCompletions.removeValue(forKey: fetchId)
        fetchProgress.removeValue(forKey: fetchId)
        fetchRecords.removeValue(forKey: fetchId)
        persistStores()
        lock.unlock()
        completions?.forEach { $0(.failure(error)) }
    }

    // MARK: - الإشعارات

    /// طلب إذن الإشعارات مرة واحدة (عند أول تحميل) — بلا إذن لا يصل
    /// إشعار «تم التحميل» عند اكتمال التحميل خارج التطبيق.
    private func requestNotificationAuthorizationIfNeeded() {
        let flag = "mc.notifAuthRequested"
        guard !UserDefaults.standard.bool(forKey: flag) else { return }
        UserDefaults.standard.set(true, forKey: flag)
        UNUserNotificationCenter.current().requestAuthorization(
            options: [.alert, .sound, .badge]) { _, _ in }
    }

    /// إشعار «تم التحميل» — فقط إن كان التطبيق خارج الواجهة.
    private func postCompletionNotification(serverJobId: String, title: String) {
        guard UIApplication.shared.applicationState != .active else { return }
        let content = UNMutableNotificationContent()
        content.title = "تم التحميل"
        content.body = title
        content.sound = .default
        let request = UNNotificationRequest(identifier: "mc-done-\(serverJobId)",
                                            content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
    }
}

// MARK: - URLSessionDownloadDelegate (تقدم حقيقي بالبايتات)

extension DownloadManager: URLSessionDownloadDelegate {
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0,
              let fetchId = downloadTask.taskDescription else { return }
        lock.lock()
        fetchProgress[fetchId] = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        lock.unlock()
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        guard let fetchId = downloadTask.taskDescription else { return }
        // رفض أي رد ليس ملفًا حقيقيًا (401/404/500 — صفحة خطأ لا وسائط).
        if let http = downloadTask.response as? HTTPURLResponse,
           !(http.statusCode == 200 || http.statusCode == 206) {
            failFetch(fetchId: fetchId,
                      error: APIError.serverError("HTTP \(http.statusCode)"))
            return
        }
        lock.lock()
        let record = fetchRecords[fetchId]
        let completions = fetchCompletions.removeValue(forKey: fetchId)
        fetchProgress.removeValue(forKey: fetchId)
        lock.unlock()
        guard let rec = record else { return }
        // انقل الملف المؤقت إلى صندوق وارد دائم قبل انتهاء الجلسة
        // (يبقى حتى بعد إنهاء التطبيق — خلاف مجلد tmp).
        let dest = inboxURL(serverJobId: rec.serverJobId, fileName: rec.fileName)
        do {
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try FileManager.default.moveItem(at: location, to: dest)
        } catch {
            failFetch(fetchId: fetchId, error: error)
            return
        }
        lock.lock()
        completedFetches[rec.serverJobId, default: [:]][rec.fileName] = dest.path
        fetchRecords.removeValue(forKey: fetchId)
        persistStores()
        lock.unlock()
        completions?.forEach { $0(.success(dest)) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error,
              let fetchId = task.taskDescription else { return }
        let nsError = error as NSError
        // إلغاء صريح من المستخدم: لا استئناف، فشل فورًا.
        if nsError.code == NSURLErrorCancelled {
            failFetch(fetchId: fetchId, error: error)
            return
        }
        // بيانات استئناف؟ أعد المحاولة من منتصف الملف (بحد 3 محاولات)
        // — فقط إن كان الملف مكتملًا على الخادم. ملف نامٍ لا يُستأنف
        // أبدًا: الخادم يتجاهل Range للملف النامي ويعيد بثّه من
        // البداية، فبيانات الاستئناف تنتج ملفًا فاسدًا (يُعاد
        // تنزيله من جديد بدلًا من ذلك عبر حلقة الجلب).
        if let resumeData = nsError.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            lock.lock()
            let rec = fetchRecords[fetchId]
            lock.unlock()
            if let rec = rec, !rec.growing, rec.resumeCount < 3 {
                lock.lock()
                var r = rec
                r.resumeCount += 1
                fetchRecords[fetchId] = r
                persistStores()
                lock.unlock()
                let newTask = backgroundSession.downloadTask(withResumeData: resumeData)
                newTask.taskDescription = fetchId
                newTask.resume()
                return
            }
        }
        failFetch(fetchId: fetchId, error: error)
    }

    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        // يُستدعى عند اكتمال أحداث الجلسة الخلفية بعد عودة التطبيق للواجهة.
        DispatchQueue.main.async {
            if let handler = AppDelegateBackgroundCompletion.handler {
                AppDelegateBackgroundCompletion.handler = nil
                handler()
            }
        }
    }
}

/// حامل معالج إكمال الجلسة الخلفية (يُستدعى من AppDelegate).
enum AppDelegateBackgroundCompletion {
    static var handler: (() -> Void)?
}
