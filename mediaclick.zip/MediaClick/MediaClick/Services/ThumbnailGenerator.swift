// ThumbnailGenerator.swift
// توليد مصغّرات حقيقية من ملفات الفيديو على الجهاز عبر AVFoundation
// (AVAssetImageGenerator) + تصغير صور المعاينة.

import UIKit
import AVFoundation

/// مولّد مصغّرات من الوسائط المحلية.
enum ThumbnailGenerator {
    /// مصغّرة حقيقية من ملف فيديو (إطار من بداية المقطع).
    /// - Returns: ملف JPG مؤقت للمصغّرة أو nil عند الفشل.
    static func videoThumbnail(for videoURL: URL) -> URL? {
        let asset = AVAsset(url: videoURL)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 480, height: 480)
        let duration = asset.duration
        let seconds = CMTimeGetSeconds(duration)
        // إطار بعد ثانية واحدة (أو 10% من المدة للمقاطع القصيرة)
        let target = (seconds.isFinite && seconds > 2) ? 1.0 : max(0.1, seconds * 0.1)
        let time = CMTime(seconds: target, preferredTimescale: 600)
        do {
            let cgImage = try generator.copyCGImage(at: time, actualTime: nil)
            let image = UIImage(cgImage: cgImage)
            guard let data = image.jpegData(compressionQuality: 0.85) else { return nil }
            let out = FileManager.default.temporaryDirectory
                .appendingPathComponent("thumb-\(UUID().uuidString).jpg")
            try data.write(to: out, options: .atomic)
            return out
        } catch {
            return nil
        }
    }

    /// مصغّرة مصغّرة من ملف صورة (للعرض في القوائم).
    static func imageThumbnail(for imageURL: URL, maxDimension: CGFloat = 480) -> UIImage? {
        guard let image = UIImage(contentsOfFile: imageURL.path) else { return nil }
        let ratio = min(1, maxDimension / max(image.size.width, image.size.height))
        guard ratio < 1 else { return image }
        let newSize = CGSize(width: image.size.width * ratio,
                             height: image.size.height * ratio)
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in image.draw(in: CGRect(origin: .zero, size: newSize)) }
    }
}
