// DownloadRules.swift
// قواعد الحدود — نفس قواعد البوت حرفيًا، معزولة في دالة نقية قابلة
// للاختبار (حتمية: نفس المدخلات تعطي نفس النتيجة دائمًا).
//  • سقف 48MB لكل ملف على الحجم الفعلي بعد التنزيل.
//  • أقصى مدة 3600 ثانية.
//  • فيديو فوق السقف ← صوت فقط + تنبيه؛ صوت فوقه أيضًا ← خطأ.

import Foundation

/// قرار الإرسال بعد اكتمال التنزيل (يطابق منطق البوت في _run_download).
struct DownloadDecision: Equatable {
    var includeVideo: Bool
    var includeAudio: Bool
    /// تنبيه يُعرض للمستخدم (notice_video_too_big) أو nil.
    var notice: String?
    /// خطأ نهائي (err_file_too_big) أو nil.
    var error: String?

    static let both = DownloadDecision(includeVideo: true, includeAudio: true,
                                       notice: nil, error: nil)
    static let audioOnlyWithNotice = DownloadDecision(
        includeVideo: false, includeAudio: true,
        notice: "notice_video_too_big", error: nil)
    static let videoOnly = DownloadDecision(includeVideo: true, includeAudio: false,
                                            notice: nil, error: nil)
    static let audioOnlySilent = DownloadDecision(
        includeVideo: false, includeAudio: true, notice: nil, error: nil)
    static let fileTooBig = DownloadDecision(
        includeVideo: false, includeAudio: false,
        notice: nil, error: "err_file_too_big")
    static let downloadFailed = DownloadDecision(
        includeVideo: false, includeAudio: false,
        notice: nil, error: "err_download")
}

/// قواعد الحدود (حتمية — بلا أي عشوائية أو اعتماد على الشبكة).
enum DownloadRules {
    /// سقف حجم الملف الواحد (بايت) — 48MB كما في البوت.
    static let maxBytes = 48 * 1024 * 1024
    /// أقصى مدة مقطع (ثوانٍ) — 3600 كما في البوت.
    static let maxDurationSeconds = 3600.0

    /// هل المدة مسموحة؟ (0 أو غائبة تعني «بلا مدة» فتُقبل).
    static func isDurationAllowed(_ duration: Double?) -> Bool {
        guard let d = duration, d > 0 else { return true }
        return d <= maxDurationSeconds
    }

    /// هل حجم الملف ضمن السقف؟
    static func isSizeAllowed(_ size: Int?) -> Bool {
        guard let s = size else { return false }
        return s <= maxBytes
    }

    /// قرار الإرسال من حجمي الفيديو والصوت الفعليين بعد التنزيل.
    /// يطابق منطق البوت حرفيًا:
    ///  • كلاهما ضمن السقف ← كلاهما.
    ///  • فيديو فوق السقف (أو بلا مزيج) + صوت سليم ← صوت فقط + تنبيه.
    ///  • فيديو سليم + صوت فوق السقف/فاشل ← فيديو وحده بصمت.
    ///  • كلاهما فوق السقف ← خطأ err_file_too_big.
    ///  • كلاهما فاشل ← خطأ err_download.
    static func decide(videoSize: Int?, audioSize: Int?) -> DownloadDecision {
        let videoOver = videoSize != nil && videoSize! > maxBytes
        let audioOver = audioSize != nil && audioSize! > maxBytes
        let videoOk = videoSize != nil && !videoOver
        let audioOk = audioSize != nil && !audioOver
        if videoOk && audioOk { return .both }
        if audioOk && !videoOk { return .audioOnlyWithNotice }
        if videoOk && !audioOk { return .videoOnly }
        if videoOver || audioOver { return .fileTooBig }
        return .downloadFailed
    }

    /// هل رابط الصور هذا يوجَّه إلى gallery-dl؟ (يطابق is_photo_url في المحرك)
    static func isPhotoURL(_ urlString: String) -> Bool {
        guard let url = URL(string: urlString),
              let host = url.host?.lowercased() else { return false }
        let path = url.path.lowercased()
        let imageExts = [".jpg", ".jpeg", ".png", ".webp", ".gif"]
        if imageExts.contains(where: { path.hasSuffix($0) }) { return true }
        if host.hasSuffix("tiktok.com") {
            let parts = path.split(separator: "/")
            if parts.count >= 3 && parts[1] == "photo" { return true }
        }
        if host.hasSuffix("instagram.com") && path.hasPrefix("/p/") { return true }
        if host.hasSuffix("pinterest.com") && path.hasPrefix("/pin/") { return true }
        return false
    }
}
