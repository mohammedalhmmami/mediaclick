// LanguageManager.swift
// إدارة لغة التطبيق: 20 لغة (نفس لغات البوت).
//  • عند أول تشغيل: تتبع لغة الجهاز تلقائيًا (إن كانت مدعومة، وإلا العربية).
//  • يمكن تغييرها يدويًا من أيقونة الكرة الأرضية؛ يُحفظ الاختيار ويُطبَّق فورًا.
//  • RTL للعربية والفارسية والأوردو (من جدول L10n).

import Foundation
import SwiftUI
import Combine

/// مدير لغة التطبيق (ObservableObject — كل الواجهات تعيد الرسم عند التغيير).
final class LanguageManager: ObservableObject {
    static let shared = LanguageManager()

    private static let storageKey = "appLanguage"

    /// رموز اللغات العشرين بالترتيب.
    static let supportedLanguages: [String] = [
        "ar", "en", "ru", "es", "fr", "de", "tr", "fa", "pt", "id",
        "zh", "ja", "ko", "hi", "ur", "bn", "th", "vi", "ms", "ta"
    ]

    /// اسم اللغة بلغتها نفسها (للقائمة).
    static let languageNames: [String: String] = [
        "ar": "العربية", "en": "English", "ru": "Русский",
        "es": "Español", "fr": "Français", "de": "Deutsch",
        "tr": "Türkçe", "fa": "فارسی", "pt": "Português",
        "id": "Bahasa Indonesia", "zh": "中文", "ja": "日本語",
        "ko": "한국어", "hi": "हिन्दी", "ur": "اردو",
        "bn": "বাংলা", "th": "ไทย", "vi": "Tiếng Việt",
        "ms": "Bahasa Melayu", "ta": "தமிழ்"
    ]

    /// علم كل لغة (للقائمة).
    static let languageFlags: [String: String] = [
        "ar": "🇸🇦", "en": "🇬🇧", "ru": "🇷🇺", "es": "🇪🇸",
        "fr": "🇫🇷", "de": "🇩🇪", "tr": "🇹🇷", "fa": "🇮🇷",
        "pt": "🇵🇹", "id": "🇮🇩", "zh": "🇨🇳", "ja": "🇯🇵",
        "ko": "🇰🇷", "hi": "🇮🇳", "ur": "🇵🇰", "bn": "🇧🇩",
        "th": "🇹🇭", "vi": "🇻🇳", "ms": "🇲🇾", "ta": "🇱🇰"
    ]

    @Published private(set) var currentLanguage: String

    private init() {
        if let saved = UserDefaults.standard.string(forKey: Self.storageKey),
           Self.supportedLanguages.contains(saved) {
            currentLanguage = saved
        } else {
            currentLanguage = Self.deviceLanguage()
        }
    }

    /// لغة الجهاز (أول رمز من حرفين) إن كانت مدعومة، وإلا العربية.
    static func deviceLanguage() -> String {
        let code = Locale.current.language.languageCode?.identifier.lowercased()
            ?? Locale.current.languageCode?.lowercased()
            ?? "ar"
        let base = code.split(separator: "-").first.map(String.init) ?? code
        return supportedLanguages.contains(base) ? base : "ar"
    }

    /// هل اللغة الحالية RTL؟
    var isRTL: Bool {
        L10n.rtlLanguages.contains(currentLanguage)
    }

    /// نص مفتاح باللغة الحالية (مع سقوط آمن).
    func t(_ key: String) -> String {
        L10n.text(key, lang: currentLanguage)
    }

    /// تغيير اللغة وحفظها وتطبيقها فورًا.
    func setLanguage(_ code: String) {
        guard Self.supportedLanguages.contains(code) else { return }
        UserDefaults.standard.set(code, forKey: Self.storageKey)
        currentLanguage = code
    }
}

// MARK: - اختصار للاستخدام في الواجهات

extension View {
    /// نص مترجم باللغة الحالية (يُعاد حسابه عند تغيير اللغة).
    func localized(_ key: String, lang: LanguageManager) -> String {
        lang.t(key)
    }
}
