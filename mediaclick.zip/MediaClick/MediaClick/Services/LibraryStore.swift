// LibraryStore.swift
// مكتبة الملفات المحفوظة على الجهاز (ملفاتي): إدارة الملفات في
// Documents/MediaClick/ + حفظ بياناتها كـ JSON. كل الملفات تبقى
// على الجهاز حتى يحذفها المستخدم بنفسه.

import Foundation
import Combine

/// مخزن مكتبة الملفات (ObservableObject ليشترك مع الواجهة).
final class LibraryStore: ObservableObject {
    static let shared = LibraryStore()

    /// مجلد المكتبة داخل Documents.
    /// ‏v2.3:‏ كان هنا ‏[0]‏ على مصفوفة قد تكون فارغة داخل ضيف
    /// ‏LiveContainer‏ (مجلد المستندات قد لا يُرجَع عند إطلاق الضيف)
    /// فيغلق التطبيق فور فتحه بخطأ فهرس — الآن بدائل آمنة متسلسلة.
    static var libraryDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return docs.appendingPathComponent("MediaClick", isDirectory: true)
    }

    /// ملف بيانات المكتبة (JSON).
    private static var indexURL: URL {
        libraryDirectory.appendingPathComponent("library.json")
    }

    @Published private(set) var files: [LibraryFile] = []

    private let queue = DispatchQueue(label: "com.mediaclick.library", attributes: .concurrent)

    private init() {
        ensureDirectory()
        load()
    }

    // MARK: - المجلد والتحميل

    private func ensureDirectory() {
        try? FileManager.default.createDirectory(
            at: Self.libraryDirectory, withIntermediateDirectories: true)
    }

    private func load() {
        guard let data = try? Data(contentsOf: Self.indexURL) else { return }
        let decoder = JSONDecoder()
        if let decoded = try? decoder.decode([LibraryFile].self, from: data) {
            // أظهر الأحدث أولًا، وتجاهل إدخالات ملفها محذوف من القرص
            files = decoded
                .filter { FileManager.default.fileExists(atPath: $0.fileURL.path) }
                .sorted { $0.createdAt > $1.createdAt }
        } else {
            // فهرس تالف: احذفه حتى لا تُعاد قراءته عند كل إطلاق
            // (الملفات نفسها تبقى على القرص).
            try? FileManager.default.removeItem(at: Self.indexURL)
        }
    }

    private func save() {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        guard let data = try? encoder.encode(files) else { return }
        try? data.write(to: Self.indexURL, options: .atomic)
    }

    // MARK: - العمليات

    /// إضافة ملف منزّل إلى المكتبة (ينقل الملف إلى مجلد المكتبة إن لزم).
    /// - Returns: إدخال المكتبة الجديد.
    @discardableResult
    func addFile(from tempURL: URL, name: String, kind: MediaKind,
                 platform: Platform, sourceURL: String, title: String?,
                 duration: Double?, thumbnailURL: URL? = nil) -> LibraryFile {
        ensureDirectory()
        let safeName = Self.uniqueFileName(for: name)
        let dest = Self.libraryDirectory.appendingPathComponent(safeName)
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: tempURL, to: dest)
        } catch {
            try? FileManager.default.copyItem(at: tempURL, to: dest)
        }
        var thumbRelative: String?
        if let thumb = thumbnailURL {
            let thumbName = "thumb-" + safeName + ".jpg"
            let thumbDest = Self.libraryDirectory.appendingPathComponent(thumbName)
            try? FileManager.default.removeItem(at: thumbDest)
            if (try? FileManager.default.moveItem(at: thumb, to: thumbDest)) != nil {
                thumbRelative = thumbName
            } else if (try? FileManager.default.copyItem(at: thumb, to: thumbDest)) != nil {
                thumbRelative = thumbName
            }
        }
        let size = (try? FileManager.default.attributesOfItem(atPath: dest.path)[.size] as? Int) ?? 0
        let entry = LibraryFile(
            id: UUID().uuidString, name: safeName, kind: kind, size: size,
            platform: platform.rawValue, sourceURL: sourceURL, title: title,
            duration: duration, relativePath: safeName,
            thumbnailPath: thumbRelative, createdAt: Date())
        DispatchQueue.main.async {
            self.files.insert(entry, at: 0)
            self.save()
        }
        return entry
    }

    /// حذف ملف من المكتبة ومن القرص.
    func deleteFile(_ file: LibraryFile) {
        try? FileManager.default.removeItem(at: file.fileURL)
        if let thumb = file.thumbnailURL {
            try? FileManager.default.removeItem(at: thumb)
        }
        DispatchQueue.main.async {
            self.files.removeAll { $0.id == file.id }
            self.save()
        }
    }

    /// حذف كل ملفات المكتبة (مع تأكيد من الواجهة قبل الاستدعاء).
    func deleteAll() {
        for file in files {
            try? FileManager.default.removeItem(at: file.fileURL)
            if let thumb = file.thumbnailURL {
                try? FileManager.default.removeItem(at: thumb)
            }
        }
        DispatchQueue.main.async {
            self.files.removeAll()
            self.save()
        }
    }

    /// إجمالي حجم المكتبة.
    var totalSize: Int {
        files.reduce(0) { $0 + $1.size }
    }

    var totalSizeText: String {
        ByteCountFormatter.string(fromByteCount: Int64(totalSize), countStyle: .file)
    }

    // MARK: - أدوات

    /// اسم ملف فريد داخل المكتبة (يضيف لاحقة رقمية عند التعارض).
    private static func uniqueFileName(for name: String) -> String {
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var candidate = name
        var n = 1
        while FileManager.default.fileExists(
            atPath: libraryDirectory.appendingPathComponent(candidate).path) {
            candidate = ext.isEmpty ? "\(base)-\(n)" : "\(base)-\(n).\(ext)"
            n += 1
        }
        return candidate
    }
}
