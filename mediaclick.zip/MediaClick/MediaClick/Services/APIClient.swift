// APIClient.swift
// عميل خادم التحميل (server/): إنشاء مهمة، استعلام الحالة، تنزيل الملفات.
// عنوان الخادم قابل للتعديل من الإعدادات (الافتراضي http://localhost:8080).

import Foundation

/// أخطاء عميل الخادم.
enum APIError: LocalizedError {
    case invalidURL
    case serverUnreachable
    case badResponse
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "عنوان الخادم غير صالح."
        case .serverUnreachable: return "تعذّر الوصول إلى خادم التحميل — تأكد أنه يعمل وأن الهاتف على الشبكة نفسها."
        case .badResponse: return "رد غير متوقع من الخادم."
        case .serverError(let msg): return msg
        }
    }
}

/// عميل HTTP لخادم التحميل.
final class APIClient {
    static let shared = APIClient()

    /// عنوان الخادم الأساسي — يُقرأ من الإعدادات في كل طلب (قابل للتغيير دون إعادة تشغيل).
    var baseURL: URL {
        let raw = UserDefaults.standard.string(forKey: "serverBaseURL")
            ?? "http://localhost:8080"
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return URL(string: trimmed) ?? URL(string: "http://localhost:8080")!
    }

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 600
        return URLSession(configuration: config)
    }()

    private init() {}

    // MARK: - الصحة

    /// فحص سريع أن الخادم يعمل (GET /api/health).
    func checkHealth() async -> Bool {
        let url = baseURL.appendingPathComponent("api/health")
        do {
            let (_, response) = try await session.data(from: url)
            return (response as? HTTPURLResponse)?.statusCode == 200
        } catch {
            return false
        }
    }

    // MARK: - إنشاء مهمة

    /// إنشاء مهمة تحميل جديدة (POST /api/download) — ترجع معرّف المهمة.
    func createJob(urlString: String) async throws -> String {
        let url = baseURL.appendingPathComponent("api/download")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(["url": urlString])
        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            throw APIError.serverUnreachable
        }
        guard let http = response as? HTTPURLResponse else { throw APIError.badResponse }
        if http.statusCode == 400 {
            throw APIError.serverError("err_invalid_url")
        }
        guard http.statusCode == 200 else { throw APIError.badResponse }
        struct Reply: Decodable { var job_id: String }
        let reply = try JSONDecoder().decode(Reply.self, from: data)
        return reply.job_id
    }

    // MARK: - حالة المهمة

    /// حالة مهمة (GET /api/job/{id}).
    func jobStatus(jobId: String) async throws -> ServerJob {
        let url = baseURL.appendingPathComponent("api/job/\(jobId)")
        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(from: url)
        } catch {
            throw APIError.serverUnreachable
        }
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw APIError.badResponse
        }
        let decoder = JSONDecoder()
        return try decoder.decode(ServerJob.self, from: data)
    }

    // MARK: - تنزيل ملف

    /// رابط تنزيل ملف من الخادم (GET /api/file/{job}/{name}).
    func fileURL(jobId: String, name: String) -> URL {
        baseURL
            .appendingPathComponent("api/file/\(jobId)")
            .appendingPathComponent(name)
    }
}
