// ContentView.swift
// الحاوية الرئيسية: قائمة جانبية قابلة للطي (درج) + المحتوى.
// القائمة: الرئيسية، ملفاتي، الدعم — فقط.

import SwiftUI

/// وجهات القائمة الجانبية.
enum MenuDestination: String, CaseIterable {
    case home
    case myFiles
    case support

    var titleKey: String {
        switch self {
        case .home: return "menu_home"
        case .myFiles: return "menu_files"
        case .support: return "menu_support"
        }
    }

    var title: String {
        LanguageManager.shared.t(titleKey)
    }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .myFiles: return "folder.fill"
        case .support: return "questionmark.circle.fill"
        }
    }
}

// MARK: - منتقي اللغة (20 لغة — يفتح من أيقونة الكرة الأرضية)

struct LanguagePickerView: View {
    @ObservedObject private var lang = LanguageManager.shared
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            List {
                ForEach(LanguageManager.supportedLanguages, id: \.self) { code in
                    Button {
                        lang.setLanguage(code) // يُحفظ ويُطبَّق فورًا
                        dismiss()
                    } label: {
                        HStack(spacing: 12) {
                            Text(LanguageManager.languageFlags[code] ?? "")
                                .font(.system(size: 22))
                            Text(LanguageManager.languageNames[code] ?? code)
                                .font(.system(size: 16))
                                .foregroundColor(Brand.textPrimary)
                            Spacer()
                            if lang.currentLanguage == code {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(Brand.success)
                                    .font(.system(size: 20))
                            }
                        }
                        .padding(.vertical, 6)
                    }
                }
            }
            .listStyle(.plain)
            .background(Brand.background.ignoresSafeArea())
            .navigationTitle(lang.t("language_title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(lang.t("close")) { dismiss() }
                }
            }
        }
    }
}

struct ContentView: View {
    @StateObject private var lang = LanguageManager.shared
    @State private var destination: MenuDestination = .home
    @State private var menuOpen = false
    @State private var showLanguagePicker = false

    var body: some View {
        ZStack(alignment: .trailing) {
            // المحتوى الرئيسي
            mainContent
                .disabled(menuOpen)
                .blur(radius: menuOpen ? 2 : 0)
                .overlay {
                    if menuOpen {
                        Color.black.opacity(0.35)
                            .ignoresSafeArea()
                            .onTapGesture { closeMenu() }
                    }
                }

            // الدرج الجانبي (ينزلق من اليمين — RTL)
            SideMenuView(selection: $destination, isOpen: $menuOpen, onSelect: {
                closeMenu()
            })
            .offset(x: menuOpen ? 0 : 320)
            .animation(.easeInOut(duration: 0.28), value: menuOpen)
        }
        .gesture(
            DragGesture()
                .onEnded { value in
                    // سحب من الحافة اليمنى يفتح القائمة؛ والسحب لليمين يغلقها
                    if value.translation.width < -60 && !menuOpen {
                        openMenu()
                    } else if value.translation.width > 60 && menuOpen {
                        closeMenu()
                    }
                }
        )
        .environment(\.layoutDirection, lang.isRTL ? .rightToLeft : .leftToRight)
        .environment(\.locale, Locale(identifier: lang.currentLanguage))
        .environmentObject(lang)
        .sheet(isPresented: $showLanguagePicker) {
            LanguagePickerView()
        }
    }

    private var mainContent: some View {
        NavigationView {
            Group {
                switch destination {
                case .home:
                    HomeView()
                case .myFiles:
                    MyFilesView()
                case .support:
                    SupportView()
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // أيقونة اللغة (كرة أرضية) + زر القائمة (همبرغر) — بينهما
                // فجوة واضحة (20pt) وهدف لمس كامل 44pt لكل منهما، حتى لا
                // يضغط المستخدم القائمة بالخطأ وهو يقصد اللغة.
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack(spacing: 20) {
                        Button(action: { showLanguagePicker = true }) {
                            Image(systemName: "globe")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 44, height: 44)
                                .contentShape(Rectangle())
                        }
                        .accessibilityLabel(lang.t("language_title"))
                        Button(action: { withAnimation { menuOpen.toggle() } }) {
                            Image(systemName: "line.3.horizontal")
                                .font(.system(size: 20, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 44, height: 44)
                                .contentShape(Rectangle())
                        }
                        .accessibilityLabel(lang.t("menu_home"))
                    }
                }
            }
        }
        .navigationViewStyle(.stack)
    }

    private func openMenu() {
        withAnimation { menuOpen = true }
    }

    private func closeMenu() {
        withAnimation { menuOpen = false }
    }
}

// MARK: - القائمة الجانبية

struct SideMenuView: View {
    @Binding var selection: MenuDestination
    @Binding var isOpen: Bool
    var onSelect: () -> Void

    var body: some View {
        VStack(alignment: .trailing, spacing: 0) {
            // رأس القائمة: الشعار
            VStack(spacing: 6) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(
                            LinearGradient(colors: [Brand.primary, Color(red: 0.6, green: 0.05, blue: 0.35)],
                                           startPoint: .topLeading, endPoint: .bottomTrailing)
                        )
                        .frame(width: 56, height: 56)
                    Image(systemName: "arrow.down.to.line")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(.white)
                }
                Text("HDGrabber")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundColor(.white)
                Text("حمّل من جميع المنصات بدقة عالية 4K")
                    .font(.system(size: 11))
                    .foregroundColor(Brand.textMuted)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 48)
            .padding(.bottom, 28)

            // عناصر القائمة — ثلاثة فقط
            ForEach(MenuDestination.allCases, id: \.self) { dest in
                Button {
                    selection = dest
                    onSelect()
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: dest.icon)
                            .font(.system(size: 18))
                            .foregroundColor(selection == dest ? Brand.primary : Brand.textSecondary)
                            .frame(width: 26)
                        Text(dest.title)
                            .font(.system(size: 17, weight: selection == dest ? .bold : .regular))
                            .foregroundColor(selection == dest ? .white : Brand.textSecondary)
                        Spacer()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 14)
                    .background(
                        selection == dest
                            ? RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.08))
                            : nil)
                }
                .padding(.horizontal, 12)
            }

            Spacer()

            Text("الإصدار 1.0")
                .font(.system(size: 12))
                .foregroundColor(Brand.textMuted)
                .padding(.bottom, 32)
        }
        .frame(width: 300)
        .background(Brand.card.ignoresSafeArea())
        .overlay(
            Rectangle()
                .fill(Color.white.opacity(0.08))
                .frame(width: 1),
            alignment: .leading)
    }
}
