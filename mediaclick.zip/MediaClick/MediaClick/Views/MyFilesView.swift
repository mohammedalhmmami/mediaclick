// MyFilesView.swift
// شاشة «ملفاتي» — مكتبة كل الملفات المحمّلة من قبل (فيديو/صوت/صور)،
 // محفوظة على الجهاز، مع تشغيل ومشاركة وحذف.

import SwiftUI
import Photos

struct MyFilesView: View {
    @StateObject private var library = LibraryStore.shared
    @EnvironmentObject private var lang: LanguageManager

    @State private var filter: MediaKind?
    @State private var selectedFile: LibraryFile?
    @State private var fileToDelete: LibraryFile?
    @State private var showDeleteAllConfirm = false
    @State private var shareItems: [Any] = []
    @State private var showShareSheet = false
    @State private var saveMessage: String?

    private var filtered: [LibraryFile] {
        guard let f = filter else { return library.files }
        return library.files.filter { $0.kind == f }
    }

    var body: some View {
        VStack(spacing: 0) {
            // ملخص المكتبة + فلاتر
            headerSection
            if library.files.isEmpty {
                EmptyStateView(
                    icon: "folder",
                    title: lang.t("empty_files_title"),
                    message: lang.t("empty_files_message"))
            } else if filtered.isEmpty {
                EmptyStateView(
                    icon: "magnifyingglass",
                    title: "لا توجد ملفات من هذا النوع",
                    message: "جرّب فلترًا آخر أو حمّل ملفات جديدة.")
            } else {
                List {
                    ForEach(filtered) { file in
                        FileRow(file: file,
                                onTap: { selectedFile = file },
                                onShare: { share(file) },
                                onSave: { saveToPhotos(file) },
                                onDelete: { fileToDelete = file })
                            .listRowBackground(Brand.card)
                            .listRowSeparatorTint(Color.white.opacity(0.08))
                    }
                }
                .listStyle(.plain)
                .background(Brand.background)
            }
        }
        .background(Brand.background.ignoresSafeArea())
        .navigationTitle(lang.t("menu_files"))
        .toolbar {
            if !library.files.isEmpty {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(lang.t("delete_all"), role: .destructive) {
                        showDeleteAllConfirm = true
                    }
                    .font(.system(size: 14))
                }
            }
        }
        .sheet(item: $selectedFile) { file in
            MediaPlayerView(file: file)
        }
        .sheet(isPresented: $showShareSheet) {
            ShareSheet(items: shareItems)
        }
        .alert(lang.t("delete_file_title"), isPresented: .constant(fileToDelete != nil)) {
            Button(lang.t("delete"), role: .destructive) {
                if let f = fileToDelete { library.deleteFile(f) }
                fileToDelete = nil
            }
            Button(lang.t("cancel"), role: .cancel) { fileToDelete = nil }
        } message: {
            Text("سيُحذف «\(fileToDelete?.name ?? "")» من جهازك نهائيًا.")
        }
        .alert(lang.t("delete_all_title"), isPresented: $showDeleteAllConfirm) {
            Button(lang.t("delete_all"), role: .destructive) { library.deleteAll() }
            Button(lang.t("cancel"), role: .cancel) {}
        } message: {
            Text("سيُحذف كل ملفات المكتبة (\(library.files.count) ملف) نهائيًا.")
        }
        .alert(saveMessage ?? "", isPresented: .constant(saveMessage != nil)) {
            Button(lang.t("ok"), role: .cancel) { saveMessage = nil }
        }
    }

    // MARK: - الرأس والفلاتر

    private var headerSection: some View {
        VStack(spacing: 10) {
            HStack {
                Text("\(library.files.count) ملف")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Brand.textSecondary)
                Text("•")
                    .foregroundColor(Brand.textMuted)
                Text(library.totalSizeText)
                    .font(.system(size: 14))
                    .foregroundColor(Brand.textSecondary)
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    FilterChip(title: lang.t("filter_all"), selected: filter == nil) {
                        filter = nil
                    }
                    FilterChip(title: lang.t("video"), selected: filter == .video) {
                        filter = .video
                    }
                    FilterChip(title: lang.t("audio"), selected: filter == .audio) {
                        filter = .audio
                    }
                    FilterChip(title: lang.t("images"), selected: filter == .image) {
                        filter = .image
                    }
                }
                .padding(.horizontal, 20)
            }
            .padding(.bottom, 8)
        }
    }

    // MARK: - الإجراءات

    private func share(_ file: LibraryFile) {
        shareItems = [file.fileURL]
        showShareSheet = true
    }

    private func saveToPhotos(_ file: LibraryFile) {
        switch file.kind {
        case .video:
            PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: file.fileURL)
            } completionHandler: { ok, _ in
                DispatchQueue.main.async {
                    saveMessage = ok ? "تم الحفظ في الصور." : "تعذّر الحفظ في الصور."
                }
            }
        case .image:
            PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAssetFromImage(atFileURL: file.fileURL)
            } completionHandler: { ok, _ in
                DispatchQueue.main.async {
                    saveMessage = ok ? "تم الحفظ في الصور." : "تعذّر الحفظ في الصور."
                }
            }
        default:
            saveMessage = "الحفظ في الصور متاح للفيديو والصور فقط — للصوت استخدم زر المشاركة."
        }
    }
}

// MARK: - شريحة فلتر

struct FilterChip: View {
    var title: String
    var selected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14, weight: selected ? .bold : .regular))
                .foregroundColor(selected ? .white : Brand.textSecondary)
                .padding(.horizontal, 14)
                .padding(.vertical, 7)
                .background(
                    Capsule().fill(selected ? Brand.primary : Color.white.opacity(0.08)))
        }
    }
}

// MARK: - صف ملف

struct FileRow: View {
    var file: LibraryFile
    var onTap: () -> Void
    var onShare: () -> Void
    var onSave: () -> Void
    var onDelete: () -> Void

    @EnvironmentObject private var lang: LanguageManager

    @State private var thumb: UIImage?

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                // أيقونة/مصغّرة
                ZStack {
                    if let t = thumb {
                        Image(uiImage: t)
                            .resizable()
                            .scaledToFill()
                    } else {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(kindColor.opacity(0.18))
                        Image(systemName: kindIcon)
                            .font(.system(size: 20))
                            .foregroundColor(kindColor)
                    }
                }
                .frame(width: 56, height: 56)
                .clipShape(RoundedRectangle(cornerRadius: 10))

                VStack(alignment: .trailing, spacing: 4) {
                    Text(file.title ?? file.name)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Brand.textPrimary)
                        .lineLimit(1)
                    HStack(spacing: 6) {
                        Text(file.kind.arabicName)
                        Text("•")
                        Text(file.sizeText)
                        if !file.durationText.isEmpty {
                            Text("•")
                            Text(file.durationText)
                        }
                    }
                    .font(.system(size: 12))
                    .foregroundColor(Brand.textSecondary)
                    Text(file.dateText)
                        .font(.system(size: 11))
                        .foregroundColor(Brand.textMuted)
                }
                Spacer()
                Menu {
                    Button(action: onShare) {
                        Label(lang.t("share"), systemImage: "square.and.arrow.up")
                    }
                    if file.kind == .video || file.kind == .image {
                        Button(action: onSave) {
                            Label(lang.t("save_to_photos"), systemImage: "photo")
                        }
                    }
                    Button(role: .destructive, action: onDelete) {
                        Label(lang.t("delete"), systemImage: "trash")
                    }
                } label: {
                    Image(systemName: "ellipsis.circle")
                        .font(.system(size: 20))
                        .foregroundColor(Brand.textSecondary)
                        .padding(6)
                }
            }
            .padding(.vertical, 6)
        }
        .buttonStyle(.plain)
        .onAppear(perform: loadThumb)
    }

    private var kindIcon: String {
        switch file.kind {
        case .video: return "play.rectangle.fill"
        case .audio: return "waveform"
        case .image: return "photo.fill"
        case .thumbnail: return "photo"
        }
    }

    private var kindColor: Color {
        switch file.kind {
        case .video: return Brand.primary
        case .audio: return Brand.accent
        case .image: return Brand.success
        case .thumbnail: return Brand.textMuted
        }
    }

    private func loadThumb() {
        if file.kind == .video {
            if let url = file.thumbnailURL,
               let img = UIImage(contentsOfFile: url.path) {
                thumb = img
                return
            }
            DispatchQueue.global(qos: .userInitiated).async {
                if let gen = ThumbnailGenerator.videoThumbnail(for: file.fileURL),
                   let img = UIImage(contentsOfFile: gen.path) {
                    DispatchQueue.main.async { thumb = img }
                }
            }
        } else if file.kind == .image {
            DispatchQueue.global(qos: .userInitiated).async {
                if let img = ThumbnailGenerator.imageThumbnail(for: file.fileURL, maxDimension: 160) {
                    DispatchQueue.main.async { thumb = img }
                }
            }
        }
    }
}
