// SupportView.swift
// شاشة «الدعم» — التواصل مع الأدمن وقناة الدعم، وإخلاء المسؤولية.
// (بلا قسم «عن التطبيق» وبلا إعدادات الخادم — العنوان والمفتاح
//  ثابتان على خادم المستخدم الافتراضي.)

import SwiftUI

struct SupportView: View {
    @EnvironmentObject private var lang: LanguageManager

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                // التواصل مع الأدمن
                card {
                    VStack(spacing: 12) {
                        SectionTitle(text: lang.t("contact_us"))
                        HStack(spacing: 12) {
                            ZStack {
                                Circle().fill(Brand.accent.opacity(0.2))
                                    .frame(width: 52, height: 52)
                                Image(systemName: "paperplane.fill")
                                    .font(.system(size: 22))
                                    .foregroundColor(Brand.accent)
                            }
                            VStack(alignment: .trailing, spacing: 4) {
                                Text("الأدمن")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(Brand.textPrimary)
                                Text("للدعم والاستفسارات والاقتراحات")
                                    .font(.system(size: 13))
                                    .foregroundColor(Brand.textSecondary)
                            }
                            Spacer()
                        }
                        Link(destination: URL(string: "https://t.me/t3waag")!) {
                            HStack {
                                Image(systemName: "at")
                                Text("@t3waag")
                                    .font(.system(size: 16, weight: .bold))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(
                                LinearGradient(colors: [Brand.accent, Color(red: 0.15, green: 0.35, blue: 0.9)],
                                               startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        Text("قناة الدعم")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundColor(Brand.textPrimary)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                        Link(destination: URL(string: "https://t.me/HDGrabber")!) {
                            HStack {
                                Image(systemName: "at")
                                Text("@HDGrabber")
                                    .font(.system(size: 16, weight: .bold))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(
                                LinearGradient(colors: [Brand.accent, Color(red: 0.15, green: 0.35, blue: 0.9)],
                                               startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                    }
                }

                // إخلاء المسؤولية (نص البوت نفسه من engine/config.py)
                card {
                    VStack(spacing: 8) {
                        SectionTitle(text: lang.t("disclaimer_title"))
                        Text(lang.t("disclaimer_text").replacingOccurrences(of: "**", with: ""))
                            .font(.system(size: 14))
                            .foregroundColor(Brand.textSecondary)
                            .lineSpacing(5)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                }
                Spacer(minLength: 16)
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
        }
        .background(Brand.background.ignoresSafeArea())
        .navigationTitle(lang.t("menu_support"))
    }

    // MARK: - أدوات

    private func card<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack { content() }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Brand.card)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Brand.cardBorder, lineWidth: 1)))
    }
}
