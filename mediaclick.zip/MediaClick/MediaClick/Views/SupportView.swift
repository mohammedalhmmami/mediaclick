// SupportView.swift
// شاشة «الدعم» — التواصل مع الأدمن، عن التطبيق، إخلاء المسؤولية،
 // وإعدادات الخادم (عنوان الخادم قابل للتعديل).

import SwiftUI

struct SupportView: View {
    @EnvironmentObject private var lang: LanguageManager
    @AppStorage("serverBaseURL") private var serverBaseURL = "http://192.3.239.105:8080"
    @AppStorage("serverToken") private var serverToken = ""
    @State private var serverReachable: Bool?
    @State private var checkingServer = false

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                // التواصل مع الأدمن
                card {
                    VStack(spacing: 12) {
                        SectionTitle(text: lang.t("contact_us"))
                        HStack(spacing: 12) {
                            ZStack {
                                Circle().fill(Brand.accent.opacity(0.2))
                                    .frame(width: 52, height: 52)
                                Image(systemName: "paperplane.fill")
                                    .font(.system(size: 22))
                                    .foregroundColor(Brand.accent)
                            }
                            VStack(alignment: .trailing, spacing: 4) {
                                Text("الأدمن")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(Brand.textPrimary)
                                Text("للدعم والاستفسارات والاقتراحات")
                                    .font(.system(size: 13))
                                    .foregroundColor(Brand.textSecondary)
                            }
                            Spacer()
                        }
                        Link(destination: URL(string: "https://t.me/t3waag")!) {
                            HStack {
                                Image(systemName: "at")
                                Text("@t3waag")
                                    .font(.system(size: 16, weight: .bold))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(
                                LinearGradient(colors: [Brand.accent, Color(red: 0.15, green: 0.35, blue: 0.9)],
                                               startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        }
                        Text("قناة الدعم: @HDGrabber")
                            .font(.system(size: 13))
                            .foregroundColor(Brand.textSecondary)
                    }
                }

                // عن التطبيق
                card {
                    VStack(spacing: 10) {
                        SectionTitle(text: lang.t("about_title"))
                        aboutRow(title: "التطبيق", value: "HDGrabber — MediaClick")
                        aboutRow(title: "الإصدار", value: "1.0")
                        aboutRow(title: "المهمة", value: "تحميل الفيديو والصوت والصور من جميع المنصات بأعلى جودة — فيديو وصوت معًا مباشرة بلا انتظار، والصور مع الصوت.")
                        aboutRow(title: "المنصات المدعومة", value: "يوتيوب، تيك توك، إنستغرام ريل، فيسبوك، إكس، بينترست، تويتش، لينكدإن، تمبلر، ساوند كلاود")
                        aboutRow(title: "الحدود", value: "48MB لكل ملف، وأقصى مدة 60 دقيقة، ولا قوائم تشغيل ولا بث مباشر.")
                        aboutRow(title: "الخصوصية", value: "لا حساب ولا تسجيل دخول ولا كوكيز إطلاقًا — تحميل مجهول فقط.")
                    }
                }

                // إعدادات الخادم
                card {
                    VStack(spacing: 10) {
                        SectionTitle(text: lang.t("server_title"))
                        Text("الاستخراج والتحميل الثقيل يجري على خادم MediaClick الخاص بك (VPS)، والتطبيق يجلب الملفات الجاهزة منه. الخادم تمرير فقط: يُحذف الملف منه فور وصوله إلى جوالك. ضع عنوان الخادم ومفتاحه هنا إن تغيّرا.")
                            .font(.system(size: 13))
                            .foregroundColor(Brand.textSecondary)
                            .lineSpacing(4)
                        TextField("http://192.3.239.105:8080", text: $serverBaseURL)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.URL)
                            .font(.system(size: 14))
                            .foregroundColor(Brand.textPrimary)
                            .padding(12)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.white.opacity(0.06)))
                        SecureField("مفتاح الخادم", text: $serverToken)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .font(.system(size: 14))
                            .foregroundColor(Brand.textPrimary)
                            .padding(12)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color.white.opacity(0.06)))
                        HStack {
                            Button(lang.t("check_connection")) {
                                Task {
                                    checkingServer = true
                                    serverReachable = await APIClient.shared.checkHealth()
                                    checkingServer = false
                                }
                            }
                            .font(.system(size: 14, weight: .bold))
                            .foregroundColor(Brand.accent)
                            .disabled(checkingServer)
                            if checkingServer {
                                ProgressView()
                                    .progressViewStyle(.circular)
                            } else if let ok = serverReachable {
                                Text(ok ? lang.t("server_ok") : lang.t("server_unreachable"))
                                    .font(.system(size: 13, weight: .semibold))
                                    .foregroundColor(ok ? Brand.success : Brand.warning)
                            }
                            Spacer()
                        }
                    }
                }

                // إخلاء المسؤولية (نص البوت نفسه من engine/config.py)
                card {
                    VStack(spacing: 8) {
                        SectionTitle(text: lang.t("disclaimer_title"))
                        Text(lang.t("disclaimer_text").replacingOccurrences(of: "**", with: ""))
                            .font(.system(size: 14))
                            .foregroundColor(Brand.textSecondary)
                            .lineSpacing(5)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                }
                Spacer(minLength: 16)
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)
        }
        .background(Brand.background.ignoresSafeArea())
        .navigationTitle(lang.t("menu_support"))
    }

    // MARK: - أدوات

    private func card<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack { content() }
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Brand.card)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Brand.cardBorder, lineWidth: 1)))
    }

    private func aboutRow(title: String, value: String) -> some View {
        VStack(spacing: 4) {
            HStack {
                Text(title)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(Brand.textPrimary)
                Spacer()
            }
            Text(value)
                .font(.system(size: 13))
                .foregroundColor(Brand.textSecondary)
                .lineSpacing(4)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
    }
}
