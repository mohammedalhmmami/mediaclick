// Components.swift
// مكونات واجهة مشتركة: بطاقات النتائج، شريط التقدم، شريحة المنصة.
// تصميم داكن مميز بهوية HDGrabber.

import SwiftUI

// MARK: - الألوان والهوية

enum Brand {
    static let background = Color(red: 0.05, green: 0.06, blue: 0.10)
    static let card = Color(red: 0.10, green: 0.11, blue: 0.17)
    static let cardBorder = Color.white.opacity(0.08)
    static let primary = Color(red: 0.95, green: 0.10, blue: 0.22)   // أحمر HDGrabber
    static let accent = Color(red: 0.25, green: 0.55, blue: 1.0)
    static let textPrimary = Color.white
    static let textSecondary = Color.white.opacity(0.65)
    static let textMuted = Color.white.opacity(0.45)
    static let success = Color(red: 0.20, green: 0.80, blue: 0.40)
    static let warning = Color(red: 1.0, green: 0.75, blue: 0.20)
}

// MARK: - شريحة المنصة المكتشفة (تظهر فور اللصق — بلا أي شبكة)

struct PlatformChip: View {
    var platform: Platform

    var body: some View {
        HStack(spacing: 6) {
            if platform.isBrandImage {
                Image(platform.iconName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 18, height: 18)
            } else {
                Image(systemName: "globe")
                    .font(.system(size: 14))
            }
            Text(platform.displayName)
                .font(.system(size: 13, weight: .semibold))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Capsule().fill(Brand.accent.opacity(0.25)))
        .overlay(Capsule().stroke(Brand.accent.opacity(0.5), lineWidth: 1))
    }
}

// MARK: - شريط تقدم

struct DownloadProgressBar: View {
    var progress: Double // 0...1
    var height: CGFloat = 8

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: height / 2)
                    .fill(Color.white.opacity(0.12))
                RoundedRectangle(cornerRadius: height / 2)
                    .fill(
                        LinearGradient(colors: [Brand.primary, Brand.accent],
                                       startPoint: .leading, endPoint: .trailing)
                    )
                    .frame(width: max(0, geo.size.width * CGFloat(min(max(progress, 0), 1))))
                    .animation(.easeInOut(duration: 0.3), value: progress)
            }
        }
        .frame(height: height)
    }
}

// MARK: - بطاقة نتيجة واحدة (أيقونة فيديو/صوت/صور)

struct ResultIconCard: View {
    var title: String
    var subtitle: String
    var badge: String?
    var thumbnail: UIImage?
    var systemIcon: String
    var tint: Color
    var action: () -> Void
    /// الضغط المطوّل: حفظ ومشاركة (تُمرَّر من بطاقة النتيجة).
    var onSave: (() -> Void)? = nil
    var onShare: (() -> Void)? = nil

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                ZStack(alignment: .bottomTrailing) {
                    Group {
                        if let thumb = thumbnail {
                            Image(uiImage: thumb)
                                .resizable()
                                .scaledToFill()
                        } else {
                            RoundedRectangle(cornerRadius: 16)
                                .fill(tint.opacity(0.18))
                            Image(systemName: systemIcon)
                                .font(.system(size: 34))
                                .foregroundColor(tint)
                        }
                    }
                    .frame(maxWidth: 92)
                    .aspectRatio(1, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(Color.white.opacity(0.15), lineWidth: 1))
                    if let badge = badge {
                        Text(badge)
                            .font(.system(size: 12, weight: .bold))
                            .foregroundColor(.white)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(Capsule().fill(Brand.primary))
                            .offset(x: 4, y: 4)
                    }
                }
                Text(title)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Brand.textPrimary)
                    .lineLimit(1)
                Text(subtitle)
                    .font(.system(size: 11))
                    .foregroundColor(Brand.textSecondary)
                    .lineLimit(1)
            }
        }
        .buttonStyle(.plain)
        // الضغط المطوّل يفتح قائمة الحفظ والمشاركة؛ والضغطة العادية
        // (action) تفتح المقطع وتشغّله تلقائيًا.
        .contextMenu {
            if let onSave = onSave {
                Button {
                    onSave()
                } label: {
                    Label(LanguageManager.shared.t("save_to_photos"), systemImage: "square.and.arrow.down")
                }
            }
            if let onShare = onShare {
                Button {
                    onShare()
                } label: {
                    Label(LanguageManager.shared.t("share"), systemImage: "square.and.arrow.up")
                }
            }
        }
    }
}

// MARK: - صف أيقونات المنصات (للعرض فقط — ليست قابلة للضغط إطلاقًا)
// لا توجد أي إيماءة ضغط ولا أي تمييز عند اللمس على هذه الأيقونات.
// هي تعرض فقط المنصات المدعومة.

struct PlatformIconsRow: View {
    private let platforms: [Platform] = [
        .youtube, .tiktok, .instagram, .facebook, .x,
        .pinterest, .twitch, .linkedin, .tumblr, .soundcloud
    ]

    var body: some View {
        // 10 أيقونات بعرض ثابت كانت تبلغ 402pt فتُقصّ أطرافها على
        // الشاشات الضيقة — الآن تُحسب المسافات من عرض الشاشة الفعلي
        // فتبقى الأيقونات 26pt ويتقلص الفراغ بينها تلقائيًا.
        GeometryReader { geo in
            let count = CGFloat(platforms.count)
            let maxIcon: CGFloat = 26
            let spacing = max(2, min(14, (geo.size.width - maxIcon * count) / (count - 1)))
            let size = min(maxIcon, (geo.size.width - spacing * (count - 1)) / count)
            HStack(spacing: spacing) {
                ForEach(platforms) { platform in
                    Image(platform.iconName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: size, height: size)
                        .accessibilityLabel(platform.displayName)
                    // قصدًا: بلا Button وبلا onTapGesture وبلا أي تفاعل.
                }
            }
            .frame(maxWidth: .infinity, alignment: .center)
        }
        .frame(height: 26)
    }
}

// MARK: - عنوان قسم

struct SectionTitle: View {
    var text: String

    var body: some View {
        HStack {
            Text(text)
                .font(.system(size: 17, weight: .bold))
                .foregroundColor(Brand.textPrimary)
            Spacer()
        }
    }
}

// MARK: - حالة فارغة

struct EmptyStateView: View {
    var icon: String
    var title: String
    var message: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundColor(Brand.textMuted)
            Text(title)
                .font(.system(size: 17, weight: .bold))
                .foregroundColor(Brand.textPrimary)
            Text(message)
                .font(.system(size: 14))
                .foregroundColor(Brand.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
        }
        .padding(.vertical, 40)
    }
}
