// MediaPlayerView.swift
// مشغّل الوسائط: فيديو (AVPlayer)، صوت (مشغّل صوتي)، وصور (عرض بملء الشاشة).

import SwiftUI
import AVKit

struct MediaPlayerView: View {
    var file: LibraryFile

    @Environment(\.dismiss) private var dismiss
    @State private var shareItems: [Any] = []
    @State private var showShareSheet = false

    var body: some View {
        NavigationView {
            Group {
                switch file.kind {
                case .video:
                    VideoPlayer(player: AVPlayer(url: file.fileURL))
                        .background(Color.black)
                case .audio:
                    audioPlayer
                case .image:
                    imageViewer
                case .thumbnail:
                    imageViewer
                }
            }
            .background(Brand.background.ignoresSafeArea())
            .navigationTitle(file.title ?? file.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("إغلاق") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        shareItems = [file.fileURL]
                        showShareSheet = true
                    } label: {
                        Image(systemName: "square.and.arrow.up")
                    }
                }
            }
            .sheet(isPresented: $showShareSheet) {
                ShareSheet(items: shareItems)
            }
        }
    }

    // MARK: - مشغّل الصوت

    private var audioPlayer: some View {
        AudioPlayerView(file: file)
    }

    // MARK: - عارض الصور

    private var imageViewer: some View {
        Group {
            if let img = UIImage(contentsOfFile: file.fileURL.path) {
                ScrollView([.horizontal, .vertical]) {
                    Image(uiImage: img)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            } else {
                EmptyStateView(icon: "photo", title: "تعذّر عرض الصورة",
                               message: "الملف غير موجود أو تالف.")
            }
        }
    }
}

// MARK: - مشغّل صوتي بسيط (تشغيل/إيقاف + شريط تقدم)

struct AudioPlayerView: View {
    var file: LibraryFile

    @State private var player: AVPlayer?
    @State private var isPlaying = false
    @State private var currentTime: Double = 0
    @State private var duration: Double = 0
    @State private var timer: Timer?

    var body: some View {
        VStack(spacing: 24) {
            ZStack {
                Circle()
                    .fill(Brand.accent.opacity(0.18))
                    .frame(width: 180, height: 180)
                Image(systemName: "waveform")
                    .font(.system(size: 64))
                    .foregroundColor(Brand.accent)
            }
            Text(file.title ?? file.name)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(Brand.textPrimary)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .padding(.horizontal, 24)
            Text(file.platformEnum.displayName)
                .font(.system(size: 14))
                .foregroundColor(Brand.textSecondary)
            VStack(spacing: 6) {
                Slider(value: $currentTime, in: 0...(duration > 0 ? duration : 1)) { editing in
                    if !editing, let p = player {
                        p.seek(to: CMTime(seconds: currentTime, preferredTimescale: 600))
                    }
                }
                .tint(Brand.accent)
                HStack {
                    Text(timeText(currentTime))
                    Spacer()
                    Text(timeText(duration))
                }
                .font(.system(size: 12))
                .foregroundColor(Brand.textMuted)
                .monospacedDigit()
            }
            .padding(.horizontal, 24)
            Button(action: togglePlay) {
                Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 72))
                    .foregroundColor(Brand.primary)
            }
            Spacer()
        }
        .padding(.top, 40)
        .onAppear(perform: setup)
        .onDisappear(perform: teardown)
    }

    private func setup() {
        let p = AVPlayer(url: file.fileURL)
        player = p
        if let d = p.currentItem?.asset.duration {
            let s = CMTimeGetSeconds(d)
            if s.isFinite { duration = s }
        }
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            guard let p = player else { return }
            currentTime = CMTimeGetSeconds(p.currentTime())
            if let d = p.currentItem?.duration {
                let s = CMTimeGetSeconds(d)
                if s.isFinite { duration = s }
            }
            if currentTime >= duration && duration > 0 {
                isPlaying = false
            }
        }
        p.play()
        isPlaying = true
    }

    private func teardown() {
        timer?.invalidate()
        timer = nil
        player?.pause()
        player = nil
    }

    private func togglePlay() {
        guard let p = player else { return }
        if isPlaying {
            p.pause()
        } else {
            if currentTime >= duration && duration > 0 {
                p.seek(to: .zero)
            }
            p.play()
        }
        isPlaying.toggle()
    }

    private func timeText(_ t: Double) -> String {
        guard t.isFinite else { return "00:00" }
        let m = Int(t) / 60
        let s = Int(t) % 60
        return String(format: "%02d:%02d", m, s)
    }
}
